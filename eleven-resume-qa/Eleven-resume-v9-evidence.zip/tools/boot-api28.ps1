$base=Join-Path $env:TEMP 'eleven-api30-v5-gpd'
$olddir=Join-Path $base 'emu-archive-31\emulator'
$ErrorActionPreference='Stop'
$root=$PSScriptRoot;Set-Location -LiteralPath $root
$sdk=Join-Path $base 'sdk'
$env:ANDROID_HOME=$sdk; $env:ANDROID_SDK_ROOT=$sdk
$homeTest=Join-Path $root 'avd-user'
$env:ANDROID_USER_HOME=Join-Path $homeTest '.android';$env:ANDROID_SDK_HOME=$homeTest
$env:ANDROID_EMULATOR_HOME=$env:ANDROID_USER_HOME;$env:ANDROID_AVD_HOME=Join-Path $env:ANDROID_USER_HOME 'avd'
$env:ADB_SERVER_SOCKET='tcp:127.0.0.1:5072';$env:ANDROID_ADB_SERVER_PORT='5072'
$env:ANDROID_PREFS_ROOT=$env:ANDROID_USER_HOME;$env:ANDROID_EMULATOR_USE_SYSTEM_LIBS=$null
$env:PATH="$olddir;$olddir\lib64;$olddir\lib64\qt\lib;$olddir\lib64\qt\bin;$env:PATH"; $emu=Join-Path $olddir 'emulator.exe';$adir=Join-Path $env:ANDROID_AVD_HOME 'Eleven_ResumeQA_28.avd'
$imgs=Join-Path $sdk 'system-images\android-28\google_apis'
foreach($f in @($homeTest,$env:ANDROID_USER_HOME,$env:ANDROID_AVD_HOME,$adir,(Join-Path $root 'evidence'))){New-Item -Path $f -ItemType Directory -Force | Out-Null}
if(-not (Test-Path -LiteralPath $emu) -or -not (Test-Path -LiteralPath "$imgs\x86_64\system.img")){throw 'Required read-only toolchain missing'}
$cfg=@('AvdId=Eleven_ResumeQA_28','PlayStore.enabled=false','abi.type=x86_64','avd.ini.displayname=Eleven QA Android 9','avd.ini.encoding=UTF-8','hw.accelerometer=yes','hw.audioInput=no','hw.audioOutput=yes','hw.battery=yes','hw.camera.back=none','hw.camera.front=none','hw.cpu.arch=x86_64','hw.cpu.ncore=2','hw.device.name=Eleven QA API 28','hw.gps=no','hw.gpu.enabled=yes','hw.gpu.mode=swiftshader_indirect','hw.keyboard=yes','hw.lcd.density=200','hw.lcd.height=800','hw.lcd.width=480','hw.ramSize=2048','hw.sensors.proximity=no','hw.trackBall=no','disk.dataPartition.size=1536M','fastboot.forceColdBoot=yes','image.sysdir.1=system-images\android-28\google_apis\x86_64\','showDeviceFrame=no','tag.display=Google APIs','tag.id=google_apis','target=android-28','vm.heapSize=192')
$cfg|Set-Content -LiteralPath "$adir\config.ini" -Encoding ascii
@("avd.ini.encoding=UTF-8","path=$adir","target=android-28")|Set-Content -LiteralPath "$env:ANDROID_AVD_HOME\Eleven_ResumeQA_28.ini" -Encoding ascii
Get-Content -LiteralPath (Join-Path $olddir 'source.properties') | Tee-Object -FilePath 'evidence\emulator-version.txt'
& (Join-Path $olddir 'emulator-check.exe') accel | Tee-Object -FilePath 'evidence\emulator-accel.txt'
if($LASTEXITCODE -ne 0){throw 'Emulator could not use native GPD acceleration'}
$adb=Join-Path $sdk 'platform-tools\adb.exe'
& $adb -P 5072 --one-device emulator-5620 start-server
if($LASTEXITCODE -ne 0){throw 'Isolated ADB server failed'}
if(([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()|Where-Object { $_.Port -in @(5620,5621)})){throw 'QA port is occupied, not reusing a different device'}
$params=@('-avd','Eleven_ResumeQA_28','-no-window','-no-audio','-no-snapshot','-no-boot-anim','-gpu','swiftshader_indirect','-show-kernel','-verbose','-feature','-Vulkan,-EncryptUserData','-accel','on','-cores','2','-memory','2048','-port','5620')

# Only if the archive's authoritative template is exactly 1 MiB of zeros.
$template=Join-Path $imgs 'x86_64\userdata.img'
if((Get-Item -LiteralPath $template).Length -eq 1048576){
 $sha=[Security.Cryptography.SHA256]::Create();$zeros=New-Object byte[] 1048576
 $expected=[BitConverter]::ToString($sha.ComputeHash($zeros)).Replace('-','')
 if((Get-FileHash -LiteralPath $template -Algorithm SHA256).Hash -eq $expected){
   $fresh=Join-Path $root 'clean-userdata.ext4'
   if(-not (Test-Path -LiteralPath $fresh)){throw 'Blank SDK template detected but no verified fresh ext4 created'}
   $fs=[IO.File]::OpenRead($fresh);try{$fs.Seek(1080,[IO.SeekOrigin]::Begin)|Out-Null;$m1=$fs.ReadByte();$m2=$fs.ReadByte();if($fs.Length -ne 1073741824 -or $m1 -ne 0x53 -or $m2 -ne 0xef){throw 'Invalid prepared isolated ext4'}}finally{$fs.Dispose()}
   $params+=@('-data',$fresh,'-partition-size','1024')
   "Official userdata.img is exactly 1 MiB of zeros ($expected); using newly formatted 1 GiB private ext4 with encryption feature." | Set-Content -LiteralPath 'evidence\userdata-init.txt' -Encoding ascii
 }
}

$tempEnc=Join-Path $root 'encryption-slot-5f1.raw'
$params+=@('-qemu','-global','virtio-blk-pci.multifunction=on','-blockdev',"driver=file,node-name=encRaw,filename=$($tempEnc.Replace([char]92,[char]47))",'-blockdev','driver=raw,node-name=manualenc,file=encRaw','-device','virtio-blk-pci,drive=manualenc,bus=pci.0,addr=05.1')
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class GpdQaNoFaultUI { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint flags); }'
[GpdQaNoFaultUI]::SetErrorMode(32771)|Out-Null
$proc=Start-Process -WindowStyle Hidden -FilePath $emu -ArgumentList $params -WorkingDirectory $root -RedirectStandardOutput "$root\evidence\emulator-start.out" -RedirectStandardError "$root\evidence\emulator-start.err" -PassThru
"LAUNCHED $($proc.Id)";$proc.Id|Set-Content '.\emulator-launch.pid' -Encoding ascii
$end=(Get-Date).AddMinutes(5)
while((Get-Date) -lt $end){
  $devs=& $adb -P 5072 devices
  if($devs -match 'emulator-5620\s+device'){ $b=& $adb -P 5072 -s emulator-5620 shell getprop sys.boot_completed; if("$b".Trim() -eq '1'){& $adb -P 5072 -s emulator-5620 shell getprop ro.build.version.release; & $adb -P 5072 -s emulator-5620 shell getprop ro.build.version.sdk; "BOOTED";exit 0} }
  if($proc.HasExited -and $proc.ExitCode -ne 0){Get-Content "$root\evidence\emulator-start.err" -Tail 35;throw "Emulator exited $($proc.ExitCode)"}
  Start-Sleep -Seconds 4
}
Get-Content "$root\evidence\emulator-start.out" -Tail 25;Get-Content "$root\evidence\emulator-start.err" -Tail 25;throw 'Private Android 9 QA emulator boot not verified in 5 min'









