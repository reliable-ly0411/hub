from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
API=int(sys.argv[1]);VERSION=sys.argv[2]
PORT,SERIAL=('5072','emulator-5620') if API==28 else ('5073','emulator-5622')
PKG='com.cyanogenmod.eleven.standalone'
ACTIVITY=PKG+'/com.cyanogenmod.eleven.ui.activities.HomeActivity'
ADB=Path(os.environ.get('ELEVEN_QA_ADB',Path(os.environ['TEMP'])/'eleven-api30-v5-gpd/sdk/platform-tools/adb.exe'))
FIXTURE=Path(os.environ.get('ELEVEN_RESUME_AUDIO',Path(os.environ['TEMP'])/'eleven-cm121-qa/teal-samples/03.mp3'))
TITLE='Eleven Teal Sample 03'
SHA={'v9':'903f0fd6201b5d313b3a9413e886064ea26272a8f7fad09d463e4d710a8a5831',
     'v13':'e12920cd65514a5bdbbb6e36a0694df7b4ad044ebd4542981d96473ed914188e'}
APK={'v9':BASE/'work/cover-safety-v11/baseline/Eleven.apk',
     'v13':BASE/'outputs/Eleven-v13-media-art-candidate.apk'}
E=ROOT/'evidence'/f'api{API}'/VERSION;E.mkdir(parents=True,exist_ok=True)

def adb(*args,raw=False,check=True,timeout=50):
    p=subprocess.run([str(ADB),'-P',PORT,'-s',SERIAL,*map(str,args)],capture_output=True,timeout=timeout)
    if check and p.returncode:raise RuntimeError((args,p.returncode,p.stderr.decode('utf-8','replace')))
    return p.stdout if raw else p.stdout.decode('utf-8','replace').strip()

def sh(*args,**kw):return adb('shell',*args,**kw)
def guard():
    assert adb('emu','avd','name').splitlines()[0]==f'Eleven_ResumeQA_{API}'
    assert sh('getprop','ro.kernel.qemu')=='1' and sh('getprop','ro.build.version.sdk')==str(API)

def save(name,value):
    (E/name).write_text(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def screen(name):
    (E/(name+'.png')).write_bytes(adb('exec-out','screencap','-p',raw=True))

def pid():return sh('pidof',PKG,check=False)
def key(n):sh('input','keyevent',n)
def tap(x,y):sh('input','tap',x,y)
def launcher_entry():
    sh('am','start','-a','android.intent.action.MAIN','-c','android.intent.category.LAUNCHER',
       '-f','0x10200000','-n',ACTIVITY)

def focus():
    windows=sh('dumpsys','window')
    return next((s.strip() for s in windows.splitlines() if 'mCurrentFocus=' in s),'')

def wait_focus(in_app, seconds=4):
    end=time.monotonic()+seconds
    observed=focus()
    while time.monotonic()<end and (not observed or (PKG in observed)!=in_app):
        time.sleep(.20);observed=focus()
    assert observed and (PKG in observed)==in_app,observed
    return observed

def prepare():
    guard()
    assert hashlib.sha256(APK[VERSION].read_bytes()).hexdigest()==SHA[VERSION]
    installed=sh('pm','path',PKG,check=False)
    if installed:
        apkpath=installed.splitlines()[0].removeprefix('package:')
        known=sh('sha256sum',apkpath,check=False).split()
        if not known or known[0]!=SHA[VERSION]:
            assert known and known[0] in SHA.values(), 'Unexpected installed APK in disposable AVD'
            adb('uninstall',PKG)
            installed=''
    if not installed:print(adb('install',APK[VERSION]),flush=True)
    apkpath=sh('pm','path',PKG).splitlines()[0].removeprefix('package:')
    assert sh('sha256sum',apkpath).split()[0]==SHA[VERSION]
    sh('pm','grant',PKG,'android.permission.READ_EXTERNAL_STORAGE')
    sh('svc','wifi','disable');sh('svc','data','disable',check=False)
    sh('settings','put','global','airplane_mode_on','1')
    key(224);sh('wm','dismiss-keyguard',check=False)
    save('fingerprint.txt',sh('getprop','ro.build.fingerprint'))
    media_uri='content://media/external/audio/media'
    remote='/sdcard/Music/ElevenResumeQA'
    projection='_id:title:duration:is_music'
    media=sh('content','query','--uri',media_uri,'--projection',projection)
    if TITLE not in media:
        sh('mkdir','-p',remote);adb('push',FIXTURE,remote+'/03.mp3')
        canonical='/storage/emulated/0/Music/ElevenResumeQA/03.mp3'
        if API==30:
            rows=sh('content','query','--uri','content://media/external/file','--projection','_id:_data:is_pending')
            pending=re.search(r'_id=(\d+), _data='+re.escape(canonical)+r', is_pending=1',rows)
            if pending:
                sh('content','update','--uri','content://media/external_primary/file/'+pending[1],
                   '--bind','is_pending:i:0')
        sh('am','broadcast','-a','android.intent.action.MEDIA_SCANNER_SCAN_FILE','-d','file://'+canonical)
        for _ in range(20):
            media=sh('content','query','--uri',media_uri,'--projection',projection)
            if TITLE in media:break
            time.sleep(.3)
    assert re.search(r'title=Eleven Teal Sample 03, duration=\d+, is_music=1',media),media
    save('media-index.txt',media)
    save('apk-and-fixture.json',{'apk_sha256':SHA[VERSION],'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest()})

def get_state():
    dump=sh('dumpsys','media_session')
    for block in re.split(r'^\s{4}(?=\S)',dump,flags=re.M):
        if 'description='+TITLE not in block or 'package='+PKG not in block:continue
        m=re.search(r'PlaybackState \{state=(\d+), position=(-?\d+)',block)
        if m:return {'state':int(m[1]),'position_ms':int(m[2])},dump
    # Preserve unconfirmed sessions instead of accepting a state from another app.
    return None,dump

def state(tag):
    observed,raw=get_state();save(tag+'-session.txt',raw);return observed

def wait_for(expected,tag=None,seconds=4):
    end=time.monotonic()+seconds
    while True:
        observed,raw=get_state()
        if (observed and observed['state']==expected) or time.monotonic()>=end:
            if tag:save(tag+'-session.txt',raw)
            return observed
        time.sleep(.23)

def start_track():
    launcher_entry();time.sleep(.45)
    wait_focus(True)
    tap(286,131);time.sleep(.35)
    screen('initial-library');tap(164,236)
    playing=wait_for(3,'initial-playing');assert playing and playing['state']==3

def pause_progress(tag):
    key(127)
    result=wait_for(2,tag);assert result and result['state']==2,result
    return result['position_ms']

def leave(route,tag):
    if route in ('launcher','recents'):
        key(3);wait_focus(False)
    elif route=='settings':
        sh('am','start','-a','android.settings.SETTINGS');time.sleep(.35)
        wait_focus(False)
    elif route=='lock':
        key(223);time.sleep(.25)
        power=sh('dumpsys','power');assert re.search(r'mWakefulness=(Asleep|Dozing)',power),power[:850]
        save(tag+'-sleep.txt',power)

def enter(route,tag):
    if route=='launcher':launcher_entry()
    elif route=='recents':
        key(187);time.sleep(.45);screen(tag+'-recents')
        tap(240,385)
    elif route=='settings':key(4)
    elif route=='lock':
        key(224);time.sleep(.35);sh('wm','dismiss-keyguard',check=False)
    end=time.monotonic()+3
    while time.monotonic()<end:
        found=focus()
        if PKG in found:return found
        time.sleep(.23)
    screen(tag+'-unexpected-return')
    raise AssertionError(f'Not on Eleven after {route}: {found}')

def fallback(tag):
    key(126);x=wait_for(3,tag+'-media-key')
    if x and x['state']==3:
        time.sleep(.70);return 'media_key',pause_progress(tag+'-media-key-progress')
    sh('am','force-stop',PKG);launcher_entry();time.sleep(.65)
    tap(432,766);x=wait_for(3,tag+'-reopened')
    if not x or x['state']!=3:
        start_track()
    time.sleep(.7);return 'reopen',pause_progress(tag+'-reopen-progress')

def run():
    prepare();guard()
    for buffer in ('crash','events'):sh('logcat','-b',buffer,'-c',check=False)
    sh('am','force-stop',PKG);start_track()
    time.sleep(.6);pause_progress('initial-position')
    rows=[]
    cases=[('launcher',True,4),('recents',True,4),('recents',False,4),('settings',True,5),
           ('settings',False,5),('lock',True,5),('lock',False,5),('launcher',False,30)]
    for number,(route,playing,hold) in enumerate(cases,1):
        tag=f'{number:02}-{route}-'+('playing' if playing else 'paused')
        item={'case':tag,'background_seconds':hold,'was_playing':playing,'pid_before':pid()}
        try:
            paused=state(tag+'-before')
            assert paused and paused['state']==2,paused
            item['before_position_ms']=paused['position_ms']
            if playing:
                tap(430,766);base=wait_for(3,tag+'-before-active')
                assert base and base['state']==3,base
            leave(route,tag);item['while_away_focus']=focus();time.sleep(hold)
            item['while_away']=state(tag+'-away');item['return_focus']=enter(route,tag)
            item['pid_on_return']=pid();item['task_returned']=True
            item['as_returned']=state(tag+'-returned');screen(tag+'-returned')
            if not playing:
                tap(430,766)
            returned=wait_for(3,tag+'-continued',3)
            if returned and returned['state']==3:
                time.sleep(.8)
                item['after_position_ms']=pause_progress(tag+'-measured')
                item['advanced_ms']=item['after_position_ms']-item['before_position_ms']
            item['ok_without_reopen']=item.get('advanced_ms',0)>500
            if not item['ok_without_reopen']:
                recovery,where=fallback(tag);item['recovery']=recovery;item['recovered_position_ms']=where
            item['pid_after']=pid()
        except Exception as failure:
            item['harness_or_session_error']=f'{type(failure).__name__}: {failure}'
            screen(tag+'-error')
            key(224);sh('wm','dismiss-keyguard',check=False);launcher_entry()
            old=wait_for(3,tag+'-after-error',1)
            if old and old['state']==3:pause_progress(tag+'-error-paused')
            elif not old:start_track();pause_progress(tag+'-error-reset')
        rows.append(item);save('partial.json',rows)
        print(tag,item.get('ok_without_reopen'),item.get('advanced_ms'),item.get('pid_on_return'),item.get('harness_or_session_error',''),flush=True)
    crashes=sh('logcat','-b','crash','-d','-v','threadtime',check=False)
    events=sh('logcat','-b','events','-d','-s','am_crash:I','am_anr:I',check=False)
    save('crash.txt',crashes);save('crash-anr-events.txt',events)
    save('summary.json',{'api':API,'version':VERSION,'apk_sha256':SHA[VERSION],'cases':rows,
        'eleven_crash_or_anr':PKG in crashes or PKG in events})

def audio_focus():
    prepare();guard()
    companion='com.google.android.music' if API==28 else 'com.android.music'
    info=json.loads((E/'apk-and-fixture.json').read_text())
    media=(E/'media-index.txt').read_text()
    song=re.search(r'_id=(\d+), title='+TITLE,media)[1]
    uri='content://media/external/audio/media/'+song
    sh('am','force-stop',PKG);start_track();before=pid();time.sleep(.55)
    first=state('focus-start');p0=first['position_ms']
    save('focus-owned-by-eleven.txt',sh('dumpsys','audio'))
    intent=sh('am','start','-a','android.intent.action.VIEW','-d',uri,'-t','audio/mpeg',
              '--grant-read-uri-permission','-p',companion)
    save('focus-companion-launch.txt',intent);time.sleep(1.5)
    during=sh('dumpsys','audio');save('focus-during.txt',during);screen('focus-during')
    observed=state('focus-companion-playing')
    stack=during.replace('\r\n','\n').split('Audio Focus stack entries',1)[-1].split('\n\n',1)[0]
    owners=re.findall(r'-- pack:\s+([^\s]+)',stack)
    has_focus=bool(owners and owners[-1]==companion)
    if companion in focus():key(4)
    if PKG not in focus():launcher_entry()
    wait_focus(True)
    item={'companion':companion,'competing_audio_confirmed':has_focus,'focus_stack':owners,'pid_before':before,
          'pid_after_return':pid(),'while_companion':observed,'as_returned':state('focus-return')}
    if has_focus:
        s=item['as_returned'];assert s,s
        if s['state']!=3:tap(430,766)
        active=wait_for(3,'focus-resumed')
        if active and active['state']==3:
            time.sleep(.85);p1=pause_progress('focus-after-progress')
            item['advanced_ms']=p1-p0;item['ok_without_reopen']=p1-p0>500
        else:
            item['ok_without_reopen']=False;item['recovery'],_=fallback('focus')
    info.update(item);save('focus-summary.json',info);print(item,flush=True)

def full_player():
    prepare();guard()
    sh('am','force-stop',PKG);start_track()
    tap(155,766);time.sleep(.55);screen('full-player-before')
    initial=pid()
    p0=pause_progress('full-player-paused')
    leave('recents','full-player');time.sleep(5);enter('recents','full-player')
    screen('full-player-returned');after=pid()
    tap(241,680);s=wait_for(3,'full-player-resumed')
    item={'pid_before':initial,'pid_after_return':after,'as_playing':s}
    if s and s['state']==3:
        time.sleep(.85);p1=pause_progress('full-player-after-progress')
        item['advanced_ms']=p1-p0;item['ok_without_reopen']=p1-p0>500
    else:
        item['ok_without_reopen']=False;item['recovery'],_=fallback('full-player')
    save('full-player-summary.json',item);print(item,flush=True)

if __name__=='__main__':
    mode=sys.argv[3] if len(sys.argv)>3 else 'lifecycle'
    {'lifecycle':run,'audio-focus':audio_focus,'full-player':full_player}[mode]()
