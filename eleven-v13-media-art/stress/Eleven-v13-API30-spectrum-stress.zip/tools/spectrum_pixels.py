from pathlib import Path
import json
import os
from PIL import Image

root=Path(__file__).resolve().parent/os.environ.get('ELEVEN_STRESS_EVIDENCE','evidence-v13')/'api30/spectrum'
files=[root/f'frame-{i}.png' for i in range(1,6)]
frames=[Image.open(p).convert('RGB') for p in files]
assert all(im.size==(480,800) for im in frames)
def distance(a,b):return max(abs(x-y) for x,y in zip(a,b))
def teal(rgb):
    r,g,b=rgb
    return 65<=g<=195 and g-r>=40 and b-r>=35 and abs(g-b)<55

lanes=[7+15*i for i in range(32)]
roi=(0,106,480,579)
def bar_at(image, x, y):
    col=image.getpixel((x,y));left=image.getpixel((max(0,x-8),y));right=image.getpixel((min(479,x+7),y))
    return teal(col) and max(distance(col,left),distance(col,right))>=9

changes=[]
for before,after in zip(frames,frames[1:]):
    counts=[]
    for x in lanes:
        counts.append(sum(teal(before.getpixel((x,y))) and teal(after.getpixel((x,y)))
                          and distance(before.getpixel((x,y)),after.getpixel((x,y)))>=10
                          for y in range(roi[1],roi[3],2)))
    changes.append({'changed_lanes':sum(count>=5 for count in counts),'changed_samples':sum(counts)})

visible=[sum(sum(bar_at(im,x,y) for y in range(512,579,3))>=10 for x in lanes) for im in frames]
result={'roi':roi,'bar_centres':lanes,'teal_lanes_near_baseline':visible,'adjacent_frame_differences':changes}
(root/'pixels.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
assert max(visible)>=25
assert sum(x['changed_lanes']>=8 and x['changed_samples']>=50 for x in changes)>=2
