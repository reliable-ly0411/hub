import os
from pathlib import Path
import re
import time
import stress as t

def main():
    t.guard();assert t.API==30
    seed=Path(os.environ.get('ELEVEN_STRESS_AUDIO',Path(os.environ['TEMP'])/'eleven-cm121-qa/teal-samples/03.mp3'))
    remote='/sdcard/Music/ElevenTealFinalQA'
    t.sh('mkdir','-p',remote);t.adb('push',seed,remote+'/03.mp3')
    rows=t.sh('content','query','--uri','content://media/external/file','--projection','_id:_data:is_pending')
    pending=re.search(r'_id=(\d+), _data=/storage/emulated/0/Music/ElevenTealFinalQA/03\.mp3, is_pending=1',rows)
    if pending:
        t.sh('content','update','--uri','content://media/external_primary/file/'+pending[1],'--bind','is_pending:i:0')
    t.sh('am','broadcast','-a','android.intent.action.MEDIA_SCANNER_SCAN_FILE','-d',
         'file:///storage/emulated/0/Music/ElevenTealFinalQA/03.mp3')
    time.sleep(.4)
    rows=t.sh('content','query','--uri','content://media/external/audio/media','--projection','title:album_id:is_music')
    assert 'Eleven Teal Sample 03' in rows
    t.sh('am','force-stop',t.PKG);t.clear_logs()
    t.start();initial=t.pid();assert initial
    t.sh('input','tap','400','64');time.sleep(.42);t.focus('SearchActivity')
    t.input_commands([['text','Eleven%sTeal%sSample%s03']]);time.sleep(.6)
    t.shot('spectrum/search');t.sh('input','tap','157','200');time.sleep(.8)
    state=t.track_state(3);assert 'Eleven Teal Sample 03' in state
    t.save('spectrum/initial-playing.txt',state)
    t.sh('input','keyevent','4');t.sh('input','keyevent','4');t.start();t.focus('HomeActivity')
    t.sh('input','tap','454','65');time.sleep(.35);t.sh('input','tap','302','186');time.sleep(.48)
    t.focus('SettingsActivity');t.shot('spectrum/settings')
    t.sh('input','tap','420','180');time.sleep(.7)
    permissions=t.sh('dumpsys','package',t.PKG)
    if 'RECORD_AUDIO: granted=true' not in permissions:
        t.shot('spectrum/audio-permission')
        t.sh('input','tap','236','411');time.sleep(.5)
        assert 'RECORD_AUDIO: granted=true' in t.sh('dumpsys','package',t.PKG)
    t.sh('input','keyevent','4');time.sleep(.5);t.sh('input','tap','158','766');time.sleep(.65)
    capture(initial)

def capture(initial):
    state=t.track_state(3);assert 'Eleven Teal Sample 03' in state
    t.save('spectrum/playing.txt',state)
    audio=t.sh('dumpsys','media.audio_flinger');t.save('spectrum/audioflinger.txt',audio)
    if 'name: Visualizer' not in audio:
        t.save('spectrum/first-effect-probe.txt',audio)
        t.sh('input','keyevent','127');t.sh('input','keyevent','126');time.sleep(.7)
        audio=t.sh('dumpsys','media.audio_flinger');t.save('spectrum/audioflinger.txt',audio)
    assert re.search(r'\d+ effects for session [1-9]\d*',audio) and 'name: Visualizer' in audio
    for i in range(1,6):
        t.shot(f'spectrum/frame-{i}');time.sleep(.37);assert t.pid()==initial
    crash=t.sh('logcat','-b','crash','-d','-v','threadtime',check=False)
    t.save('spectrum/crash.txt',crash)
    t.save('spectrum/summary.json',{'api':t.API,'apk_sha256':t.SHA,'initial_pid':initial,'final_pid':t.pid(),
        'sample':'Eleven Teal Sample 03','playback_confirmed':True,'session_visualizer':True,'frames':5,
        'eleven_crash_or_anr':t.PKG in crash})
    assert t.PKG not in crash

if __name__=='__main__':
    import sys
    if 'capture-current' in sys.argv:
        t.guard();capture(t.pid())
    else:
        main()
