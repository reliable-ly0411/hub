import json
import hashlib
import re
import time
import zipfile
from pathlib import Path
import stress as t

def publish_pending(directory):
    rows=t.sh('content','query','--uri','content://media/external/file',
               '--projection','_id:_data:is_pending')
    ids=re.findall(fr'_id=(\d+), _data=/storage/emulated/0/Music/{directory}/EraQA\d+\.\w+, is_pending=1',rows)
    if ids:
        seq=' '.join(ids)
        t.sh(f'for i in {seq}; do content update --uri content://media/external_primary/file/$i --bind is_pending:i:0; done')

def scoped_playback():
    dump=t.sh('dumpsys','media_session')
    candidates=re.findall(r'PlaybackState \{state=(\d+), position=(-?\d+)[^\n]*\}',dump)
    labels=re.findall(r'\bmetadata:[^\n]*description=(EraQA\d+[^\n]*)',dump)
    return dump,candidates,labels

def attempt(track):
    prefix=track['prefix']
    t.sh('input','tap','400','64');time.sleep(.36);t.focus('SearchActivity')
    t.input_commands([['text',prefix]]);time.sleep(.42)
    t.shot(f'era/{prefix}-search')
    # The ordinary search screen shows Songs with the first row around y=200.
    t.sh('input','tap','164','200')
    for _ in range(5):
        time.sleep(.30)
        start,states,labels=scoped_playback()
        if any(s[0]=='3' for s in states) and any(x.startswith(prefix) for x in labels):break
    t.save(f'era/{prefix}-playing.txt',start)
    if not(any(s[0]=='3' for s in states) and any(x.startswith(prefix) for x in labels)):
        return {'outcome':'playback_unconfirmed','metadata':labels}
    time.sleep(.65)
    t.sh('input','keyevent','127');time.sleep(.26)
    end,states,labels=scoped_playback()
    t.save(f'era/{prefix}-paused.txt',end)
    positions=[int(m[1]) for m in states if m[0]=='2']
    if positions and max(positions)>300 and any(x.startswith(prefix) for x in labels):
        return {'outcome':'played_and_advanced','position_ms_at_pause':max(positions),'metadata':labels}
    return {'outcome':'playback_unconfirmed','metadata':labels,'positions_at_pause':positions}

def main():
    t.guard()
    info=json.loads((t.R/'fixtures/era-manifest.json').read_text(encoding='utf-8'))
    directory='ElevenEraFormatQA';remote='/sdcard/Music/'+directory
    t.sh('mkdir','-p',remote);t.adb('push',str(t.R/'fixtures/era')+'/.' ,remote)
    if t.API==30:
        publish_pending(directory)
    scan_dir='/storage/emulated/0/Music/'+directory if t.API==30 else remote
    t.sh(f'for f in {scan_dir}/*; do am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://$f" >/dev/null; done')
    time.sleep(1)
    audio=t.sh('content','query','--uri','content://media/external/audio/media','--projection',
               '_id:_display_name:title:year:is_music:duration:mime_type')
    files=t.sh('content','query','--uri','content://media/external/file','--projection',
               '_id:_display_name:media_type:mime_type')
    t.save('era/indexed-audio.txt','\n'.join(s for s in audio.splitlines() if 'EraQA' in s))
    t.save('era/indexed-files.txt','\n'.join(s for s in files.splitlines() if 'EraQA' in s))
    assert 'EraQA01.wav' in audio and 'EraQA06.mp3' in audio, 'Known-good fixture publication failed'
    t.sh('am','force-stop',t.PKG);t.clear_logs()
    t.start();p=t.pid();assert p
    result={'api':t.API,'apk_sha256':t.SHA,'initial_pid':p,'tracks':[]}
    for track in info['tracks']:
        prefix=track['prefix']
        row=next((s for s in audio.splitlines() if f'_display_name={track["file"]},' in s),None)
        record={**track,'audio_row':row}
        if not row or 'is_music=1' not in row:
            record['outcome']='not_in_music_library'
        else:
            record['year_seen']=(re.search(r', year=(\d+)',row) or [None,None])[1]
            record['title_seen']=re.search(r', title=(.*?), year=',row)[1]
            record.update(attempt(track))
            t.sh('input','keyevent','4');t.sh('input','keyevent','4');t.start()
        assert t.pid()==p,(track['prefix'],p,t.pid())
        result['tracks'].append(record)
        print(prefix,track['profile'],record['outcome'],record.get('year_seen'),flush=True)
    result['final_pid']=t.pid()
    crash=t.sh('logcat','-b','crash','-d','-v','threadtime',check=False)
    events=t.sh('logcat','-b','events','-d','-s','am_crash:I','am_anr:I',check=False)
    t.save('era/crash.txt',crash);t.save('era/crash-anr-events.txt',events)
    result['eleven_crash_or_anr']=t.PKG in crash or t.PKG in events
    t.save('era/summary.json',result)
    assert not result['eleven_crash_or_anr']

if __name__=='__main__':main()
