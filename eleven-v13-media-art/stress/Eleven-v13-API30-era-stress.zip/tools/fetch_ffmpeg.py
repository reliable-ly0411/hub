from pathlib import Path
import hashlib,json,urllib.request,zipfile
root=Path('work/cover-stress/tools');root.mkdir(exist_ok=True)
with urllib.request.urlopen('https://pypi.org/pypi/imageio-ffmpeg/0.6.0/json',timeout=15) as r:j=json.load(r)
f=next(f for f in j['urls'] if f['filename'].endswith('win_amd64.whl'))
p=root/f['filename']
if not p.exists():
 with urllib.request.urlopen(f['url'],timeout=40) as r:p.write_bytes(r.read())
assert hashlib.sha256(p.read_bytes()).hexdigest()==f['digests']['sha256']
with zipfile.ZipFile(p) as z:
 name=next(n for n in z.namelist() if n.endswith('.exe'))
 (root/'ffmpeg.exe').write_bytes(z.read(name))
 print(f['filename'],f['digests']['sha256'],name)
