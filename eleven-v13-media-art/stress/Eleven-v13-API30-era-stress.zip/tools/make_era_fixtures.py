from pathlib import Path
import hashlib
import json
import os
import subprocess

R=Path(__file__).resolve().parent
dest=R/'fixtures/era';dest.mkdir(parents=True,exist_ok=True)
ffmpeg=Path(os.environ.get('ELEVEN_STRESS_FFMPEG',R/'tools/ffmpeg.exe'))
audio=Path(os.environ.get('ELEVEN_STRESS_AUDIO',Path(os.environ['TEMP'])/'eleven-cm121-qa/teal-samples/03.mp3'))
matrix=[
    (1958,'wav','PCM 16-bit mono 22.05 kHz','pcm_s16le', ['-ar','22050','-ac','1']),
    (1976,'aiff','AIFF PCM 16-bit big endian','pcm_s16be',['-ar','44100','-ac','2']),
    (1986,'wav','CD-rate WAV PCM 16-bit','pcm_s16le',['-ar','44100','-ac','2']),
    (1993,'mp2','MPEG Layer II at 192 kbps','mp2',['-ar','48000','-b:a','192k']),
    (1997,'mp3','MP3 ID3v1 only, 32 kbps mono','libmp3lame',['-ar','22050','-ac','1','-b:a','32k','-id3v2_version','0','-write_id3v1','1']),
    (2001,'mp3','MP3 ID3v2.3 CBR with Chinese title','libmp3lame',['-ar','44100','-b:a','128k','-id3v2_version','3']),
    (2002,'wma','WMA v2 in ASF','wmav2',['-b:a','96k']),
    (2005,'ogg','Ogg Vorbis','libvorbis',['-q:a','4']),
    (2007,'m4a','AAC-LC in M4A','aac',['-profile:a','aac_low','-b:a','128k','-movflags','+faststart']),
    (2009,'aac','AAC-LC raw ADTS','aac',['-profile:a','aac_low','-b:a','96k']),
    (2010,'flac','FLAC 16-bit 44.1 kHz','flac',['-ar','44100','-sample_fmt','s16']),
    (2013,'m4a','Apple Lossless in M4A','alac',['-ar','44100','-sample_fmt','s16p']),
    (2016,'opus','Ogg Opus with .opus extension','libopus',['-ar','48000','-b:a','80k']),
    (2016,'ogg','Ogg Opus with .ogg extension','libopus',['-ar','48000','-b:a','80k']),
    (2023,'flac','FLAC 24-bit 96 kHz','flac',['-ar','96000','-sample_fmt','s32','-bits_per_raw_sample','24']),
    (2024,'mp3','MP3 ID3v2.4 VBR with Chinese title','libmp3lame',['-q:a','2','-id3v2_version','4']),
]
records=[]
for index,(year,ext,profile,codec,options) in enumerate(matrix,1):
    prefix=f'EraQA{index:02}'
    title=prefix+(' 旧版合辑' if index==6 else ' 新版合辑' if index==16 else '')
    out=dest/(prefix+'.'+ext)
    subprocess.run([str(ffmpeg),'-nostdin','-hide_banner','-loglevel','error','-y','-i',str(audio),
        '-t','18','-map','0:a:0','-map_metadata','-1','-metadata','title='+title,
        '-metadata','artist=Eleven Era QA','-metadata','album=Era QA '+str(index),
        '-metadata','date='+str(year),'-c:a',codec,*options,str(out)],check=True)
    b=out.read_bytes()
    if index==5:
        assert not b.startswith(b'ID3')
        # FFmpeg versions differ in whether they emit the legacy footer with ID3v2 disabled.
        if b[-128:-125]!=b'TAG':
            fixed=lambda s,n:s.encode('ascii')[:n].ljust(n,b'\0')
            b+=b'TAG'+fixed(title,30)+fixed('Eleven Era QA',30)+fixed('Era QA 5',30)+fixed(str(year),4)+bytes(31)
            out.write_bytes(b)
        assert b[-128:-125]==b'TAG' and b[-35:-31]==b'1997'
    if index in (6,16):assert b[:4]==b'ID3'+bytes([3 if index==6 else 4])
    # Decode locally as a control before using the Android player.
    p=subprocess.run([str(ffmpeg),'-nostdin','-hide_banner','-loglevel','error','-i',str(out),'-f','null','-'],capture_output=True)
    assert p.returncode==0,(out.name,p.stderr)
    records.append({'prefix':prefix,'file':out.name,'title':title,'year_requested':year,
        'profile':profile,'codec':codec,'options':options,'sha256':hashlib.sha256(b).hexdigest()})
version=subprocess.check_output([str(ffmpeg),'-version'],text=True).splitlines()[0]
(dest.parent/'era-manifest.json').write_text(json.dumps({'source':'same synthetic test audio for all encodings',
    'source_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'generator':version,'tracks':records},
    ensure_ascii=False,indent=2),encoding='utf-8')
print(f'{len(records)} era/encoding fixtures generated and independently decoded')
