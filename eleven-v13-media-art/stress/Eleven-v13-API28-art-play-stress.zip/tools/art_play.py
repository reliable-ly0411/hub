import re
import time
import stress as t

def main():
    t.guard();assert t.API==28
    results=[]
    for index,case in [('001','large square JPEG'),('003','16×30000 raw portrait PNG'),
                       ('011','30000×16 raw panorama PNG')]:
        query='StressArt'+index
        folder='art-play/'+query+'-'
        t.sh('am','force-stop',t.PKG);t.clear_logs();t.start();before=t.pid()
        t.sh('input','tap','400','64');time.sleep(.37);t.focus('SearchActivity')
        t.input_commands([['text',query]]);time.sleep(.55);t.shot(folder+'search')
        t.sh('input','tap','160','196');time.sleep(1.5)
        after=t.pid()
        state=t.sh('dumpsys','media_session');t.save(folder+'session.txt',state)
        crash=t.sh('logcat','-b','crash','-d','-v','threadtime',check=False)
        t.save(folder+'crash.txt',crash)
        playing=bool(re.search(r'PlaybackState \{state=3\b',state) and ('description='+query) in state)
        record={'query':query,'case':case,'from_pid':before,'to_pid':after,
                'playing':playing,'eleven_crash':t.PKG in crash,
                'framework_resize_error':'width and height must be > 0' in crash}
        results.append(record);print(record,flush=True)
        if playing:
            t.sh('input','keyevent','127');time.sleep(.25)
            pause=t.track_state(2);t.save(folder+'paused.txt',pause)
            record['made_progress']=int(re.search(r'state=2, position=(\d+)',pause)[1])>300
    summary={'api':t.API,'apk_sha256':t.SHA,'tracks':results,
             'eleven_crash_or_anr':any(r['eleven_crash'] for r in results)}
    t.save('art-play/summary.json',summary)

if __name__=='__main__':main()
