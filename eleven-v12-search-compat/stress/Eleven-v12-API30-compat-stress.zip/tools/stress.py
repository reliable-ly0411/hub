from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time

R=Path(__file__).resolve().parent
PREV=R.parent/'cover-safety-v11'
APK=Path(os.environ.get('ELEVEN_STRESS_APK', PREV/'build/Eleven-v11-cover-safety-candidate.apk'))
ADB=Path(os.environ.get('ELEVEN_QA_ADB', Path(os.environ['TEMP'])/'eleven-api30-v5-gpd/sdk/platform-tools/adb.exe'))
PKG='com.cyanogenmod.eleven.standalone'
SHA=os.environ.get('ELEVEN_STRESS_SHA','ed0e821583abf8096ffbed0db14365561b9b239c29c79891a4514c4c1e374f24')
API=int(os.environ.get('ELEVEN_STRESS_API','28'))
PORT,SERIAL=('5066','emulator-5610') if API==28 else ('5067','emulator-5612')
E=R/os.environ.get('ELEVEN_STRESS_EVIDENCE','evidence')/f'api{API}'
E.mkdir(exist_ok=True,parents=True)
MUSIC='/sdcard/Music/ElevenStressQA'
CACHE='/sdcard/Android/data/'+PKG+'/cache/ImageCache'

def adb(*args, timeout=100, check=True):
    p=subprocess.run([str(ADB),'-P',PORT,'-s',SERIAL,*map(str,args)],capture_output=True,timeout=timeout)
    out=p.stdout.decode('utf-8',errors='replace').strip()
    if check and p.returncode:
        raise RuntimeError((args,p.returncode,out,p.stderr.decode(errors='replace')))
    return out

def sh(*args,**kw):return adb('shell',*args,**kw)
def guard():
    assert adb('emu','avd','name').splitlines()[0]==f'Eleven_CoverStress_{API}'
    assert sh('getprop','ro.kernel.qemu')=='1' and sh('getprop','ro.build.version.sdk')==str(API)

def pid():return sh('pidof',PKG,check=False)
def save(name,data):
    p=E/name
    p.parent.mkdir(exist_ok=True,parents=True)
    p.write_text(data if isinstance(data,str) else json.dumps(data,indent=2),encoding='utf-8')

def shot(name):
    out=E/(name+'.png');out.parent.mkdir(exist_ok=True,parents=True)
    sh('screencap','-p','/data/local/tmp/eleven-stress.png')
    adb('pull','/data/local/tmp/eleven-stress.png',out)

def sample(name):
    p=pid();assert p.isdigit(), f'No single app process: {p}'
    mem=sh('dumpsys','meminfo','-d',p)
    status=sh('cat',f'/proc/{p}/status',check=False)
    fd=sh(f'ls /proc/{p}/fd 2>/dev/null | wc -l',check=False)
    result={'name':name,'pid':p,'fd':int(fd) if fd.isdigit() and int(fd)>0 else None}
    pss=re.search(r'^\s*TOTAL\s+(\d+)\s',mem,re.M)
    if pss:result['pss_kib']=int(pss[1])
    for kind in ('Native','Dalvik'):
        m=re.search(rf'^\s*{kind} Heap\s+((?:\d+[ \t]+)+)',mem,re.M)
        if m and len(m[1].split())>=6:result[kind.lower()+'_heap_alloc_kib']=int(m[1].split()[5])
    rss=re.search(r'VmRSS:\s+(\d+)',status)
    if rss:result['rss_kib']=int(rss[1])
    save(name+'-mem.txt',mem+'\n\n'+status+'\n\nFD='+str(result['fd']))
    print(result,flush=True)
    return result

def seed():
    guard()
    save('fingerprint.txt',sh('getprop','ro.build.fingerprint'))
    assert hashlib.sha256(APK.read_bytes()).hexdigest()==SHA
    if API==28:
        adb('root');adb('wait-for-device');guard()
    print(adb('install','-r',APK),flush=True)
    installed=sh('pm','path',PKG).splitlines()[0].removeprefix('package:')
    assert sh('sha256sum',installed).split()[0]==SHA
    sh('pm','grant',PKG,'android.permission.READ_EXTERNAL_STORAGE')
    sh('settings','put','global','airplane_mode_on','1');sh('svc','wifi','disable');sh('svc','data','disable',check=False)
    sh('am','broadcast','-a','android.intent.action.AIRPLANE_MODE','--ez','state','true',check=False)
    sh('input','keyevent','224');sh('wm','dismiss-keyguard',check=False)
    sh('mkdir','-p',MUSIC)
    files=sorted((R/'fixtures/music').glob('*.mp3'))
    if API==28:
        adb('push', str(R/'fixtures/music')+'/.',MUSIC,timeout=200)
        total=320
        sh(f'for f in {MUSIC}/*.mp3; do am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://$f" >/dev/null; done',timeout=240)
    else:
        files=[p for p in files if int(p.stem[-3:])<=48]
        dir30=R/'fixtures/music-api30';dir30.mkdir(exist_ok=True)
        import shutil
        for p in files:shutil.copyfile(p,dir30/p.name)
        adb('push',str(dir30)+'/.' ,MUSIC,timeout=120)
        total=96
        def pending_rows():
            rows=sh('content','query','--uri','content://media/external/audio/media','--projection','_id:_data:is_pending')
            return re.findall(r'_id=(\d+), _data=/storage/emulated/0/Music/ElevenStressQA/Stress\w+\.mp3, is_pending=1',rows)
        pending=pending_rows()
        if pending:
            seq=' '.join(pending)
            sh(f'for i in {seq}; do content update --uri content://media/external_primary/audio/media/$i --bind is_pending:i:0 >/dev/null; done',timeout=240)
    for _ in range(30):
        media=sh('content','query','--uri','content://media/external/audio/media','--projection','_id:title:is_music:album_id:duration')
        hits=re.findall(r'title=Stress(?:Art|Plain)\d{3}, is_music=1',media)
        if len(hits)==total:break
        time.sleep(1)
    save('indexed-tracks.txt',media)
    assert len(hits)==total,(total,len(hits))
    if API==28:
        covers=sh('content','query','--uri','content://media/external/audio/albums','--projection','_id:album:album_art')
        assert len(re.findall(r'album=Stress Plain Album \d{3}, album_art=NULL',covers))==160
        save('indexed-albums.txt',covers)
    print(f'{total} indexed tracks',flush=True)

def install_candidate():
    guard()
    assert hashlib.sha256(APK.read_bytes()).hexdigest()==SHA
    sh('am','force-stop',PKG)
    print(adb('install','-r',APK),flush=True)
    installed=sh('pm','path',PKG).splitlines()[0].removeprefix('package:')
    assert sh('sha256sum',installed).split()[0]==SHA
    save('installed-apk.txt',SHA)
    original=R/'evidence'/f'api{API}'
    for name in ('fingerprint.txt','indexed-tracks.txt','indexed-albums.txt','raw-inputs.json'):
        if (original/name).exists() and original!=E:
            save(name,(original/name).read_text(encoding='utf-8'))

def prepare_raw():
    guard();assert API==28
    sh('am','force-stop',PKG)
    albums=(E/'indexed-albums.txt').read_text()
    source=R/'fixtures/images'
    variants=('huge.jpg','wide.png','tall.png','progressive.jpg','webp.webp','alpha.png','broken.jpg','truncated.jpg','empty.jpg')
    provider=[];disk=[]
    diskdir=R/'fixtures/seed-disk'
    diskdir.mkdir(exist_ok=True)
    journal=['libcore.io.DiskLruCache','1','1','1','']
    candidates=re.findall(r'_id=(\d+), album=Stress Art Album (\d{3}), album_art=(/storage/emulated/0/Android/data/com.android.providers.media/albumthumbs/\d+)',albums)
    # Distinct albums for original provider bytes and legacy application disk bytes.
    for j, (number, i, path) in enumerate(candidates[:36]):
        name=variants[j%len(variants)];f=source/name
        digest=hashlib.sha256(f.read_bytes()).hexdigest()
        if j%2==0:
            adb('push',f,path)
            proof=sh(f'content read --uri content://media/external/audio/albumart/{number} | sha256sum').split()[0]
            assert proof==digest,(i,name,proof,digest)
            provider.append({'index':i,'file':name,'sha256':digest,'album_id':number})
        else:
            key=hashlib.md5(f'Stress Art Album {i}_Eleven Stress QA_album'.encode()).hexdigest()
            (diskdir/(key+'.0')).write_bytes(f.read_bytes())
            journal.append(f'CLEAN {key} {f.stat().st_size}')
            disk.append({'index':i,'file':name,'sha256':digest,'legacy_key':key})
    (diskdir/'journal').write_bytes(('\n'.join(journal)+'\n').encode('ascii'))
    sh('mkdir','-p',CACHE);adb('push',str(diskdir)+'/.' ,CACHE)
    save('raw-inputs.json',{'provider':provider,'disk':disk})
    print(f'{len(provider)} verified raw provider covers and {len(disk)} legacy disk entries',flush=True)

def start():
    sh('am','start','-n',PKG+'/com.cyanogenmod.eleven.ui.activities.HomeActivity')
    time.sleep(.7)
    sh('input','tap','285','130')

def focus(activity):
    data=sh('dumpsys','window')
    lines=[s.strip() for s in data.splitlines() if 'mCurrentFocus' in s or 'mFocusedApp' in s]
    if not lines:
        data=sh('dumpsys','activity','activities')
        lines=[s.strip() for s in data.splitlines() if 'mResumedActivity' in s or 'topResumedActivity' in s]
    assert any(activity in line for line in lines),(activity,lines)
    return lines

def track_state(expected):
    state=sh('dumpsys','media_session')
    assert re.search(r'PlaybackState \{state='+str(expected)+r'\b',state),state[:1200]
    return state

def input_commands(commands):
    text='; '.join('input '+' '.join(shlex.quote(str(arg)) for arg in command) for command in commands)
    sh(text,timeout=100)

def stress(kind):
    guard();assert kind in ('stock','raw','compat')
    name=kind+'/';sh('am','force-stop',PKG);sh('logcat','-c');sh('logcat','-b','crash','-c',check=False)
    start();initial=pid();assert initial
    result={'kind':kind,'api':API,'apk_sha256':SHA,'initial_pid':initial,'list_swipes':0,
            'search_chars':0,'search_swipes':0,'searches':0,'background_round_trips':0,
            'sampled':[],'expected_process_restarts':0}
    def mark(label):
        values=sample(name+label)
        assert values['pid']==initial,(label,initial,values)
        result['sampled'].append(values)
    def qclear(length):
        if length:input_commands([['keyevent',*[67]*length]])
    try:
        save(name+'home-focus.txt','\n'.join(focus('HomeActivity')))
        shot(name+'first');mark('cold')
        repeat=3 if kind=='stock' else 2
        size=24 if API==28 else 12
        for cycle in range(repeat):
            for up in (True,False):
                y1,y2=(660,235) if up else (235,660)
                for batch in range(2):
                    input_commands([['swipe',250,y1,250,y2,115]]*(size//2));result['list_swipes']+=size//2
                    mark(f'list-{cycle+1}-{int(up)}-{batch}')
            if cycle==0:shot(name+'after-sweeps')
        sh('input','tap','400','64');time.sleep(.4)
        save(name+'search-focus.txt','\n'.join(focus('SearchActivity')))
        targets=['StressArt','StressPlain','StressArt01','StressPlain09','StressArt12','NoMatchXYZ']
        if kind=='raw':
            raw=json.loads((E/'raw-inputs.json').read_text())
            # Check all synthetic raw entries through the actual search results.
            targets=['StressArt'+item['index'] for k in ('provider','disk') for item in raw[k]]
        else:targets*=2 if API==28 else 1
        prior=''
        for j, query in enumerate(targets):
            if kind=='raw':
                # All targets have equal length. Re-enter each full query from blank without waiting at a prefix.
                qclear(len(prior));input_commands([['text',query]]);result['search_chars']+=len(query)
            else:
                qclear(len(prior));input_commands([['text',c] for c in query]);result['search_chars']+=len(query)
            prior=query;result['searches']+=1
            if kind=='raw':time.sleep(.36)
            else:
                input_commands([['swipe',265,470,265,205,105]]*2);result['search_swipes']+=2
            if j%6==0:mark(f'search-{j+1}');shot(name+f'search-{j+1}')
            assert pid()==initial
        sh('input','keyevent','4');time.sleep(.2)
        if kind in ('raw','compat'):
            # Select by title so adding other fixtures cannot change the first playable row.
            sh('input','keyevent','4');start()
            sh('input','tap','400','64');time.sleep(.4);focus('SearchActivity')
            input_commands([['text','StressArt001']]);time.sleep(.5)
            sh('input','tap','164','200');time.sleep(.65)
            playing=track_state(3);assert 'StressArt001' in playing, 'Expected the long StressArt001 audio fixture'
            sh('input','keyevent','4');sh('input','keyevent','4');start()
            save(name+'playing.txt',playing);shot(name+'playing');mark('playing')
            for cycle in range(5):
                sh('input','keyevent','3');time.sleep(.3)
                save(name+f'background-playing-{cycle+1}.txt',track_state(3))
                if cycle==0:
                    trim=sh('am','send-trim-memory',PKG,'RUNNING_CRITICAL',check=False)
                    save(name+'explicit-trim-command.txt',trim or '(Android command returned no text)')
                start();focus('HomeActivity');result['background_round_trips']+=1
                save(name+f'foreground-playing-{cycle+1}.txt',track_state(3))
                mark(f'foreground-{cycle+1}')
            sh('input','keyevent','127');time.sleep(.3);save(name+'paused.txt',track_state(2))
            sh('input','keyevent','126');time.sleep(.3);save(name+'resumed.txt',track_state(3))
            result['media_key_pause_resume']=True
            sh('input','tap','400','64');time.sleep(.4);focus('SearchActivity')
            input_commands([['text',c] for c in 'StressArt']);result['search_chars']+=9;result['searches']+=1
            input_commands([['swipe',265,475,265,210,110]]*16);result['search_swipes']+=16
            save(name+'search-while-playing.txt',track_state(3));shot(name+'search-while-playing')
            sh('input','keyevent','127')
        mark('warm-end')
        if kind=='raw':
            contents=sh('cat',CACHE+'/journal',check=False);save(name+'disk-journal.txt',contents)
            result['legacy_reads']=sum(('READ '+item['legacy_key']) in contents for item in raw['disk'])
            assert result['legacy_reads']>0
            sh('am','force-stop',PKG);result['expected_process_restarts']=1
            old=initial;start();initial=pid();assert initial and initial!=old
            result['disk_restart_pid']=initial;mark('warm-disk-new-process')
            sh('input','tap','400','64');time.sleep(.4);focus('SearchActivity')
            input_commands([['text',c] for c in 'StressArt001']);result['search_chars']+=12;result['searches']+=1
            shot(name+'disk-restart-search');mark('warm-disk-search')
    except Exception as failure:
        result['error']=type(failure).__name__+': '+str(failure)
    finally:
        result['final_pid']=pid();crash=sh('logcat','-b','crash','-d','-v','threadtime',check=False)
        events=sh('logcat','-b','events','-d','-s','am_crash:I','am_anr:I',check=False)
        result['eleven_crash_or_anr']=PKG in crash or PKG in events
        save(name+'crash.txt',crash);save(name+'crash-anr-events.txt',events)
        save(name+'summary.json',result)
        print(json.dumps({k:v for k,v in result.items() if k!='sampled'}),flush=True)
    assert not result.get('error') and not result['eleven_crash_or_anr'],result.get('error')

if __name__=='__main__':
    if sys.argv[1]=='seed':seed()
    elif sys.argv[1]=='install':install_candidate()
    elif sys.argv[1]=='raw-seed':prepare_raw()
    else:stress(sys.argv[1])
