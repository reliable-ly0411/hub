from pathlib import Path
import hashlib
import json
import os
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / 'fixtures'
MUSIC = INPUTS / 'music'
IMAGES = INPUTS / 'images'
MUSIC.mkdir(parents=True, exist_ok=True)
IMAGES.mkdir(exist_ok=True)
base = Path(os.environ.get('ELEVEN_PREVIOUS_QA', ROOT.parent/'cover-safety-v11'))
track = Path(os.environ.get('ELEVEN_STRESS_AUDIO', Path(os.environ['TEMP']) /
             'eleven-cm121-qa/teal-samples/03.mp3')).read_bytes()
skip = 0
if track.startswith(b'ID3'):
    for value in track[6:10]:
        skip = (skip << 7) | value
    skip += 10
audio = track[skip:]
assert audio[0] == 255

variants = {
    'normal.jpg': ((720, 720), 'JPEG', {}),
    'progressive.jpg': ((2200, 1600), 'JPEG', {'progressive': True}),
    'webp.webp': ((1100, 640), 'WEBP', {'lossless': True}),
    'alpha.png': ((850, 850), 'PNG', {}),
    'huge.jpg': ((10000, 10000), 'JPEG', {}),
    'wide.png': ((30000, 16), 'PNG', {}),
    'tall.png': ((16, 30000), 'PNG', {}),
}
for name, (size, fmt, options) in variants.items():
    mode = 'RGBA' if name=='alpha.png' else 'RGB'
    with Image.new(mode, size, (0, 135, 139, 180) if mode=='RGBA' else (0, 135, 139)) as image:
        draw = ImageDraw.Draw(image)
        width, height = size
        draw.rectangle((width//4,height//4,3*width//4,3*height//4), fill='#ee9d24')
        image.save(IMAGES/name, fmt, **options)
(IMAGES/'broken.jpg').write_bytes(b'\xff\xd8\xff\xe0\x00\x10JFIF\0' + b'invalid cover'*100)
(IMAGES/'truncated.jpg').write_bytes((IMAGES/'normal.jpg').read_bytes()[:380])
(IMAGES/'empty.jpg').write_bytes(b'')
images = {p.name:p.read_bytes() for p in IMAGES.iterdir() if p.is_file()}
pool = ['normal.jpg','progressive.jpg','webp.webp','alpha.png','normal.jpg','wide.png',
        'tall.png','huge.jpg','normal.jpg','broken.jpg','truncated.jpg','normal.jpg']

def frame(key, value):
    return key.encode('ascii') + len(value).to_bytes(4,'big') + b'\0\0' + value

records=[]
for index in range(1,161):
    for kind in ('Art','Plain'):
        title = f'Stress{kind}{index:03}'
        album = f'Stress {kind} Album {index:03}'
        artist = 'Eleven Stress QA'
        cover = pool[(index-1) % len(pool)] if kind=='Art' else None
        tags = b''.join(frame(k,b'\0'+v.encode('ascii')) for k,v in
                        [('TIT2',title),('TALB',album),('TPE1',artist)])
        if cover:
            mime = 'image/png' if cover.endswith('.png') else 'image/webp' if cover.endswith('.webp') else 'image/jpeg'
            tags += frame('APIC', b'\0'+mime.encode('ascii')+b'\0\x03\0'+images[cover])
        n=len(tags)
        path=MUSIC/(title+'.mp3')
        path.write_bytes(b'ID3\x03\0\0'+bytes((n>>i)&127 for i in (21,14,7,0))+tags+audio)
        records.append({'title':title,'album':album,'cover':cover})

(INPUTS/'manifest.json').write_text(json.dumps({'audio_frame_sha256':hashlib.sha256(audio).hexdigest(),
    'images':{k:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,b in images.items()},
    'tracks':records},indent=2))
print(f'{len(records)} synthetic tracks, {sum(p.stat().st_size for p in MUSIC.iterdir()):,} bytes')
