$ErrorActionPreference='Stop'
$root=$PSScriptRoot;Set-Location -LiteralPath $root
$sdk=Join-Path $env:TEMP 'eleven-api30-v5-gpd\sdk'
$env:ANDROID_HOME=$sdk; $env:ANDROID_SDK_ROOT=$sdk
$homeTest=Join-Path $root 'avd-user'
$env:ANDROID_USER_HOME=Join-Path $homeTest '.android';$env:ANDROID_SDK_HOME=$homeTest
$env:ANDROID_EMULATOR_HOME=$env:ANDROID_USER_HOME;$env:ANDROID_AVD_HOME=Join-Path $env:ANDROID_USER_HOME 'avd'
$env:ADB_SERVER_SOCKET='tcp:127.0.0.1:5067';$env:ANDROID_ADB_SERVER_PORT='5067'
$env:ANDROID_PREFS_ROOT=$env:ANDROID_USER_HOME;$env:ANDROID_EMULATOR_USE_SYSTEM_LIBS=$null
$env:PATH="$sdk\emulator;$sdk\emulator\lib64;$sdk\emulator\lib64\qt\lib;$sdk\emulator\lib64\qt\bin;$env:PATH"; $emu=Join-Path $sdk 'emulator\emulator.exe';$adir=Join-Path $env:ANDROID_AVD_HOME 'Eleven_CoverStress_30.avd'
$imgs=Join-Path $sdk 'system-images\android-30\default'
foreach($f in @($homeTest,$env:ANDROID_USER_HOME,$env:ANDROID_AVD_HOME,$adir,(Join-Path $root 'evidence'))){New-Item -Path $f -ItemType Directory -Force | Out-Null}
if(-not (Test-Path -LiteralPath $emu) -or -not (Test-Path -LiteralPath "$imgs\x86_64\system.img")){throw 'Required read-only tools missing'}
$cfg=@('AvdId=Eleven_CoverStress_30','PlayStore.enabled=false','abi.type=x86_64','avd.ini.displayname=Eleven QA Android 11','avd.ini.encoding=UTF-8','hw.accelerometer=yes','hw.audioInput=no','hw.audioOutput=yes','hw.battery=yes','hw.camera.back=none','hw.camera.front=none','hw.cpu.arch=x86_64','hw.cpu.ncore=2','hw.device.name=Eleven QA API 30','hw.gps=no','hw.gpu.enabled=yes','hw.gpu.mode=host','hw.keyboard=yes','hw.lcd.density=200','hw.lcd.height=800','hw.lcd.width=480','hw.ramSize=2048','hw.sensors.proximity=no','hw.trackBall=no','disk.dataPartition.size=1536M','fastboot.forceColdBoot=yes','image.sysdir.1=system-images\android-30\default\x86_64\','showDeviceFrame=no','tag.display=Default','tag.id=default','target=android-30','vm.heapSize=192')
$cfg|Set-Content -LiteralPath "$adir\config.ini" -Encoding ascii
@("avd.ini.encoding=UTF-8","path=$adir","target=android-30")|Set-Content -LiteralPath "$env:ANDROID_AVD_HOME\Eleven_CoverStress_30.ini" -Encoding ascii
Get-Content -LiteralPath (Join-Path $sdk 'emulator\source.properties') | Tee-Object -FilePath 'evidence\emulator-version.txt'
& (Join-Path $sdk 'emulator\emulator-check.exe') accel | Tee-Object -FilePath 'evidence\emulator-accel.txt'
if($LASTEXITCODE -ne 0){throw 'Emulator could not use native GPD acceleration'}
$adb=Join-Path $sdk 'platform-tools\adb.exe'
& $adb -P 5067 --one-device emulator-5612 start-server
if($LASTEXITCODE -ne 0){throw 'Isolated ADB server failed'}
if(([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()|Where-Object { $_.Port -in @(5612,5613)})){throw 'QA port is occupied, not reusing a different device'}
$params=@('-avd','Eleven_CoverStress_30','-no-window','-no-snapshot','-no-boot-anim','-gpu','host','-show-kernel','-verbose','-crash-report-mode','disabled','-feature','-Vulkan','-accel','on','-cores','2','-memory','2048','-port','5612','-no-metrics')

# Only if the archive's authoritative template is exactly 1 MiB of zeros.
$template=Join-Path $imgs 'x86_64\userdata.img'
if((Get-Item -LiteralPath $template).Length -eq 1048576){
 $sha=[Security.Cryptography.SHA256]::Create();$zeros=New-Object byte[] 1048576
 $expected=[BitConverter]::ToString($sha.ComputeHash($zeros)).Replace('-','')
 if((Get-FileHash -LiteralPath $template -Algorithm SHA256).Hash -eq $expected){
   $fresh=Join-Path $root 'clean-userdata.ext4'
   if(-not (Test-Path -LiteralPath $fresh)){throw 'Blank SDK template detected but no verified fresh ext4 created'}
   $fs=[IO.File]::OpenRead($fresh);try{$fs.Seek(1080,[IO.SeekOrigin]::Begin)|Out-Null;$m1=$fs.ReadByte();$m2=$fs.ReadByte();if($fs.Length -ne 1073741824 -or $m1 -ne 0x53 -or $m2 -ne 0xef){throw 'Invalid prepared isolated ext4'}}finally{$fs.Dispose()}
   $params+=@('-data',$fresh,'-partition-size','1024')
   "Official userdata.img is exactly 1 MiB of zeros ($expected); using newly formatted 1 GiB private ext4 with encryption feature." | Set-Content -LiteralPath 'evidence\userdata-init.txt' -Encoding ascii
 }
}

Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class GpdQaNoFaultUI { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint flags); }'
[GpdQaNoFaultUI]::SetErrorMode(32771)|Out-Null
$proc=Start-Process -WindowStyle Hidden -FilePath $emu -ArgumentList $params -WorkingDirectory $root -RedirectStandardOutput "$root\evidence\emulator-start.out" -RedirectStandardError "$root\evidence\emulator-start.err" -PassThru
"LAUNCHED $($proc.Id)";$proc.Id|Set-Content '.\emulator-launch.pid' -Encoding ascii
$end=(Get-Date).AddMinutes(5)
while((Get-Date) -lt $end){
  $devs=& $adb -P 5067 devices
  if($devs -match 'emulator-5612\s+device'){ $b=& $adb -P 5067 -s emulator-5612 shell getprop sys.boot_completed; if("$b".Trim() -eq '1'){& $adb -P 5067 -s emulator-5612 shell getprop ro.build.version.release; & $adb -P 5067 -s emulator-5612 shell getprop ro.build.version.sdk; "BOOTED";exit 0} }
  if($proc.HasExited -and $proc.ExitCode -ne 0){Get-Content "$root\evidence\emulator-start.err" -Tail 35;throw "Emulator exited $($proc.ExitCode)"}
  Start-Sleep -Seconds 4
}
Get-Content "$root\evidence\emulator-start.out" -Tail 25;Get-Content "$root\evidence\emulator-start.err" -Tail 25;throw 'Emulator boot not verified in 5 min'


