# Eleven for Android (CM12.1 standalone)

Version: `2.0-cm12.1-standalone.2` (version code 9).
Install `Eleven.apk` from this ZIP. The APK's package name is `com.cyanogenmod.eleven.standalone`.

This is a standalone port of contemporary [CyanogenMod 12.1 Eleven source](https://github.com/CyanogenMod/android_packages_apps_Eleven/tree/9d2f80421cde3459362f94ea5de7a311081c5894), not an APK extracted from the XT910 `12.1-RC5.6-umts_spyder` ROM. The exact ROM binary was not verified. The later [LineageOS 20 port](https://github.com/BlueN1nja1/Eleven) was consulted as a compatibility reference, not used as the base or UI.

The original layout, 32-band spectrum drawing and animation, and artwork/placeholder palette are unchanged. Teal is one original palette choice; the hue follows the current cover or original placeholder. Enable **Settings → Show music visualization** in Eleven. Android's Visualizer requires the audio permission; leave it off for ordinary playback. The FFT adapter uses only Eleven's active playback session and does not record files.

## Verified
- Android 9 (API 28) emulator on GPD: fresh storage denial without an app crash, fresh grant displays the scanned track without reopening, playback, on-screen and media-key pause/resume, background playback, opt-in visualization and animated spectrum; no Eleven crash observed during the run.
- Android 11 (API 30) emulator on GPD: install/launch, library playback and original teal spectrum motion on the same signed APK. Tests used synthetic audio tracks. Neither a physical Android handset nor physical speaker output was tested.
- The exact signed APK's SHA-256 is in `SHA256SUMS.txt`.

`Eleven-CM121-compat.patch` applies to the pinned public upstream above. See `BUILD.md` for reconstruction and the bundled notices for dependencies. No private signing materials are included.
