import json
import re
import time
import stress as t

def main():
    t.guard()
    era=json.loads((t.E/'era/summary.json').read_text(encoding='utf-8'))
    catalog=[r for r in era['tracks'] if r['outcome']=='not_in_music_library' or r['prefix']=='EraQA14']
    mimes={'aiff':'audio/aiff','mp2':'audio/mpeg','wma':'audio/x-ms-wma','m4a':'audio/mp4',
           'opus':'audio/opus','ogg':'application/ogg'}
    results=[]
    for track in catalog:
        prefix=track['prefix'];suffix=track['file'].rsplit('.',1)[1]
        t.sh('am','force-stop',t.PKG);t.sh('logcat','-c');t.sh('logcat','-b','crash','-c',check=False)
        argv=['am','start','-W','-a','android.intent.action.VIEW','-d',
              'file:///sdcard/Music/ElevenEraFormatQA/'+track['file'],'-t',mimes[suffix],
              '-n',t.PKG+'/com.cyanogenmod.eleven.ui.activities.preview.AudioPreviewActivity']
        t.save(f'preview/{prefix}-launch.txt',t.sh(*argv))
        time.sleep(.85)
        pid=t.pid()
        focus=t.sh('dumpsys','window')
        focused=any('AudioPreviewActivity' in s for s in focus.splitlines() if 'mCurrentFocus' in s or 'mFocusedApp' in s)
        t.save(f'preview/{prefix}-focus.txt',focus);t.shot(f'preview/{prefix}-first')
        active=t.sh('dumpsys','media.player')
        started=bool(pid and re.search(rf'pid\({pid}\).*?state\(5\).*?decoder\(',active,re.S))
        t.save(f'preview/{prefix}-player.txt',active);time.sleep(1.18);t.shot(f'preview/{prefix}-later')
        log=t.sh('logcat','-d','-v','threadtime','-s','MediaPlayer','MediaPlayerNative','NuPlayer','NuPlayerDriver',
                 'AudioPreviewActivity','MPEG4Extractor','MediaExtractor','CCodec','ACodec')
        t.save(f'preview/{prefix}-codec-log.txt',log)
        crash=t.sh('logcat','-b','crash','-d','-v','threadtime',check=False)
        events=t.sh('logcat','-b','events','-d','-s','am_crash:I','am_anr:I',check=False)
        t.save(f'preview/{prefix}-crash.txt',crash+'\n'+events)
        error=t.PKG in crash or t.PKG in events
        outcome='preview_decoder_active' if focused and started else 'preview_playback_unconfirmed'
        rec={'prefix':prefix,'file':track['file'],'profile':track['profile'],'pid':pid,
             'preview_activity_focused':focused,'decoder_started':started,'outcome':outcome,'crash_or_anr':error}
        results.append(rec);print(rec,flush=True)
        t.sh('input','keyevent','4')
    summary={'api':t.API,'apk_sha256':t.SHA,'tracks':results,
             'eleven_crash_or_anr':any(r['crash_or_anr'] for r in results)}
    t.save('preview/summary.json',summary)
    assert not summary['eleven_crash_or_anr']

if __name__=='__main__':main()
