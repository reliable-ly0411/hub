from pathlib import Path
from xml.etree import ElementTree as ET
import os, re, time, json, hashlib
import qa

def ui(label):
    remote='/data/local/tmp/eleven-api30-window.xml'
    qa.sh('uiautomator','dump',remote,check=False,timeout=15)
    xml=qa.sh('cat',remote)
    qa.save('api30-'+label+'.xml',xml)
    return list(ET.fromstring(xml).iter('node'))

def tap_node(node):
    x0,y0,x1,y1=map(int,re.findall(r'\d+',node.attrib['bounds']))
    qa.sh('input','tap',(x0+x1)//2,(y0+y1)//2)

def find(nodes, predicate):
    return next((n for n in nodes if predicate(n.attrib)), None)

def setup():
    qa.guard();assert qa.sh('getprop','ro.build.version.sdk')=='30'
    qa.save('api30-fingerprint.txt',qa.sh('getprop','ro.build.fingerprint'))
    apk=qa.R/'build/Eleven-v11-cover-safety-candidate.apk'
    print(qa.adb('install',apk),flush=True)
    assert qa.apksha()==hashlib.sha256(apk.read_bytes()).hexdigest()
    qa.sh('pm','grant',qa.PKG,'android.permission.READ_EXTERNAL_STORAGE')
    qa.sh('svc','wifi','disable');qa.sh('svc','data','disable',check=False)
    qa.sh('input','keyevent','224');qa.sh('wm','dismiss-keyguard',check=False)
    remote='/sdcard/Music/ElevenTealCandidateQA'
    qa.sh('mkdir','-p',remote)
    samples=Path(os.environ.get('ELEVEN_QA_TEAL',Path(os.environ['TEMP'])/'eleven-cm121-qa/teal-samples'))
    for n in ('01.mp3','02.mp3','03.mp3','04.mp3'):
        qa.adb('push',samples/n,remote+'/'+n)
        qa.sh('am','broadcast','-a','android.intent.action.MEDIA_SCANNER_SCAN_FILE','-d','file://'+remote+'/'+n)
    rows=qa.sh('content','query','--uri','content://media/external/audio/media',
               '--projection','_id:_data:is_pending')
    for row in rows.splitlines():
        match=re.search(r'_id=(\d+), _data=/storage/emulated/0/Music/ElevenTealCandidateQA/0[1-4]\.mp3, is_pending=1',row)
        if match:
            qa.sh('content','update','--uri','content://media/external_primary/audio/media/'+match[1],
                  '--bind','is_pending:i:0')
    for _ in range(20):
        media=qa.sh('content','query','--uri','content://media/external/audio/media','--projection','_id:title:is_music:album_id')
        if 'Eleven Teal Sample 03' in media:break
        time.sleep(.5)
    qa.save('api30-media.txt',media);assert 'Eleven Teal Sample 03' in media
    qa.sh('logcat','-c');qa.start();time.sleep(2)
    qa.sh('input','tap','285','130');time.sleep(.5)
    qa.shot('api30-library')
    target=find(ui('library'),lambda a:a.get('text')=='Eleven Teal Sample 03')
    assert target is not None;tap_node(target);time.sleep(.8)
    qa.sh('input','tap','455','65');time.sleep(.4)
    target=find(ui('overflow'),lambda a:a.get('text')=='Settings')
    assert target is not None;tap_node(target);time.sleep(.7)
    qa.shot('api30-settings')
    target=find(ui('settings'),lambda a:a.get('text')=='Show music visualization')
    assert target is not None;tap_node(target);time.sleep(.7)
    nodes=ui('audio-permission')
    allow=find(nodes,lambda a:'permission_allow_foreground_only_button' in a.get('resource-id',''))
    if allow is None:allow=find(nodes,lambda a:a.get('text') in ('While using the app','ALLOW','Allow'))
    if allow is not None:tap_node(allow)
    perms=qa.sh('dumpsys','package',qa.PKG);qa.save('api30-package.txt',perms)
    assert 'RECORD_AUDIO: granted=true' in perms
    qa.sh('input','keyevent','4');time.sleep(.5)
    qa.sh('input','tap','155','766');time.sleep(.7)
    capture()

def capture():
    pid=qa.pid();assert pid
    media=qa.sh('dumpsys','media_session');qa.save('api30-playing.txt',media)
    assert 'state=3' in media and 'Eleven Teal Sample 03' in media
    qa.save('api30-audioflinger.txt',qa.sh('dumpsys','media.audio_flinger'))
    for i in range(1,6):
        qa.shot(f'api30-spectrum-{i}');time.sleep(.38);assert qa.pid()==pid
    qa.sh('input','keyevent','127');time.sleep(.6)
    pause=qa.sh('dumpsys','media_session');qa.save('api30-paused.txt',pause)
    assert 'state=2' in pause
    qa.sh('input','keyevent','126');time.sleep(.6)
    resume=qa.sh('dumpsys','media_session');qa.save('api30-resumed.txt',resume)
    assert 'state=3' in resume
    qa.save('api30-crash.txt',qa.sh('logcat','-b','crash','-d','-v','threadtime'))
    assert qa.PKG not in (qa.E/'api30-crash.txt').read_text()
    qa.save('api30-summary.json',json.dumps({'apk_sha256':qa.apksha(),'initial_pid':pid,'final_pid':qa.pid(),'sample':'Eleven Teal Sample 03','playing':True,'media_key_pause_resume':True},indent=2))

if __name__=='__main__':
    import sys
    if 'capture' in sys.argv:capture()
    else:setup()
