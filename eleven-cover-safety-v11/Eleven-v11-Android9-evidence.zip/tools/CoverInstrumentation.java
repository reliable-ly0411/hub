package qa;
import android.app.Instrumentation;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.view.ViewGroup;
import com.cyanogenmod.eleven.cache.*;
import java.io.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Installed only on the isolated emulator; absent from the deliverable app. */
public class CoverInstrumentation extends Instrumentation {
    private Bundle args;
    private int checks;
    private final AtomicInteger open = new AtomicInteger(), peak = new AtomicInteger();
    private void check(boolean ok,String name) {
        if (!ok) throw new AssertionError(name);
        checks++;
    }
    private void note(String message) { Log.i("CoverQA",message); }
    @Override public void onCreate(Bundle a) { args=a;start(); }
    private void bounded(Bitmap b,int edge,String name) {
        check(b!=null,name+" decoded");
        check(b.getWidth()<=edge && b.getHeight()<=edge,name+" dimensions");
        check(b.getAllocationByteCount()<=(long)edge*edge*4,name+" allocation");
        note(name+" "+b.getWidth()+"x"+b.getHeight()+" bytes="+b.getAllocationByteCount());
        b.recycle();
    }
    private SafeArtwork.Source counted(final File f) {
        return new SafeArtwork.Source() {
            public InputStream open() throws IOException {
                final InputStream input=new FileInputStream(f);
                int n=open.incrementAndGet();
                peak.accumulateAndGet(n,Math::max);
                return new FilterInputStream(input) {
                    @Override public void close() throws IOException {
                        try { super.close(); } finally { open.decrementAndGet(); }
                    }
                };
            }
        };
    }
    @Override public void onStart() {
        Bundle result=new Bundle();
        try {
            Context c=getTargetContext();
            File dir=new File("/sdcard/Download/ElevenRawCoverQA");
            ImageCache cache=ImageCache.getInstance(c);
            Field field=ImageCache.class.getDeclaredField("mDiskCache");field.setAccessible(true);
            DiskLruCache disk=null;
            for(int i=0;i<100 && disk==null;i++){disk=(DiskLruCache)field.get(cache);if(disk==null)Thread.sleep(50);}
            check(disk!=null,"disk initialized");
            for(String name:new String[]{"normal.jpg","large.jpg","wide.png","tall.png"}) {
                for(int edge:new int[]{128,512,1024}) bounded(SafeArtwork.decode(counted(new File(dir,name)),edge),edge,"direct "+name+" edge="+edge);
                bounded(ImageFetcher.decodeSampledBitmapFromUri(c.getContentResolver(),Uri.fromFile(new File(dir,name))),1024,"uri "+name);
            }
            for(String name:new String[]{"broken.jpg","truncated.jpg","empty.jpg","missing.jpg"}) {
                check(ImageFetcher.decodeSampledBitmapFromUri(c.getContentResolver(),Uri.fromFile(new File(dir,name)))==null,"invalid "+name);
                note("fallback "+name);
            }
            for(String name:new String[]{"large.jpg","wide.png","tall.png","broken.jpg","empty.jpg"}) {
                String key="qa-raw-"+name,hash=ImageCache.hashKeyForDisk(key);
                DiskLruCache.Editor editor=disk.edit(hash);
                try(InputStream in=new FileInputStream(new File(dir,name));OutputStream out=editor.newOutputStream(0)) {
                    byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
                }
                editor.commit();
                Bitmap bitmap=cache.getBitmapFromDiskCache(key);
                if(name.equals("broken.jpg") || name.equals("empty.jpg")) check(bitmap==null,"disk fallback "+name);
                else bounded(bitmap,1024,"disk "+name);
            }
            int before=new File("/proc/self/fd").list().length;
            ExecutorService pool=Executors.newFixedThreadPool(8);
            List<Future<?>> jobs=new ArrayList<>();
            for(int t=0;t<8;t++) jobs.add(pool.submit(()->{
                for(int i=0;i<30;i++) {
                    Bitmap b=SafeArtwork.decode(counted(new File(dir,"large.jpg")),128);
                    if(b==null || b.getWidth()>128)throw new AssertionError("parallel decode");
                    b.recycle();
                }
            }));
            for(Future<?> f:jobs)f.get(120,TimeUnit.SECONDS);pool.shutdown();
            check(open.get()==0,"all opened streams closed");check(peak.get()<=2,"max two decoders");
            java.util.concurrent.atomic.AtomicBoolean cancellationWorked=new java.util.concurrent.atomic.AtomicBoolean();
            Thread cancelled=new Thread(()->{
                Thread.currentThread().interrupt();
                cancellationWorked.set(SafeArtwork.decode(counted(new File(dir,"large.jpg")),128)==null
                        && Thread.currentThread().isInterrupted());
            });cancelled.start();cancelled.join();
            check(cancellationWorked.get(),"cancelled decode returned without opening source");
            bounded(SafeArtwork.decode(counted(new File(dir,"normal.jpg")),128),128,"after cancellation");
            check(SafeArtwork.decode(()->{throw new SecurityException("qa");},128)==null,"security fallback");
            check(SafeArtwork.decode(()->{throw new IOException("qa");},128)==null,"io fallback");
            // Exercise the real MediaStore source without memory/disk-cache reuse.
            for(int i=0;i<120;i++) {
                Bitmap b=cache.getArtworkFromFile(c,19,128);
                check(b!=null && b.getWidth()<=128 && b.getHeight()<=128,"raw provider repeat "+i);
                b.recycle();
            }
            final ImageView[] image=new ImageView[1];
            runOnMainSync(()->{
                image[0]=new ImageView(c);image[0].setLayoutParams(new ViewGroup.LayoutParams(80,80));
                ImageFetcher fetch=ImageFetcher.getInstance(c);fetch.setImageCache(cache);
                for(int i=0;i<600;i++)fetch.loadAlbumImage("Cover QA","Cover Art Album "+String.format(Locale.US,"%02d",i%24+1),i%24+1,image[0]);
            });
            Thread.sleep(1500);
            runOnMainSync(()->ImageWorker.cancelWork(image[0]));
            Thread.sleep(500);
            Field lruField=ImageCache.class.getDeclaredField("mLruCache");lruField.setAccessible(true);
            ImageCache.MemoryCache memory=(ImageCache.MemoryCache)lruField.get(cache);
            check(memory.size()<=16*1024*1024,"memory cache bounded");
            int after=new File("/proc/self/fd").list().length;
            check(after<=before+8,"descriptor stability");
            note("PASS checks="+checks+" fd="+before+"->"+after+" open="+open+" peak="+peak+" cacheBytes="+memory.size());
            result.putString("result","PASS checks="+checks+" fd="+before+"->"+after+" peak="+peak);
            finish(0,result);
        } catch(Throwable failure) {
            Log.e("CoverQA","FAIL",failure);result.putString("failure",failure.toString());finish(1,result);
        }
    }
}
