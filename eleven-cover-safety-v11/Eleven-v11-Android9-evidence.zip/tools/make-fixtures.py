from PIL import Image
from pathlib import Path
import os,hashlib,json
r=Path(__file__).resolve().parent;d=r/'fixtures';d.mkdir(exist_ok=True)
for n,wh,fmt in [('large.jpg',(10000,10000),'JPEG'),('wide.png',(30000,16),'PNG'),('tall.png',(16,30000),'PNG'),('normal.jpg',(720,720),'JPEG')]:
 im=Image.new('RGB',wh,(0,160,160));im.save(d/n,format=fmt);im.close()
(d/'broken.jpg').write_bytes(b'\xff\xd8\xff\xe0\x00\x10JFIF\0'+b'broken cover'*64)
(d/'truncated.jpg').write_bytes((d/'normal.jpg').read_bytes()[:400])
(d/'empty.jpg').write_bytes(b'')
default_audio=Path(os.environ['TEMP'])/'eleven-cm121-qa/v9-transitions/kit/ElevenTransitionQA/Album-01/01.mp3'
mp3=Path(os.environ.get('ELEVEN_QA_AUDIO',default_audio)).read_bytes()
skip=0
if mp3[:3]==b'ID3':
 for b in mp3[6:10]:skip=(skip<<7)|b
 skip+=10
sound=mp3[skip:];assert sound[0]==255
def frame(k,b):return k.encode()+len(b).to_bytes(4,'big')+b'\0\0'+b
manifest=[]
for kind in ('Art','Plain'):
 for i in range(1,25):
  cover=['normal.jpg','large.jpg','wide.png','tall.png','broken.jpg','truncated.jpg'][(i-1)//4]
  title=f'Cover{kind}{i:02}';album=f'Cover {kind} Album {i:02}'
  tags=b''.join(frame(k,b'\0'+s.encode()) for k,s in [('TIT2',title),('TPE1','Cover QA'),('TALB',album)])
  if kind=='Art':
   mime=b'image/png' if cover.endswith('png') else b'image/jpeg'
   tags+=frame('APIC',b'\0'+mime+b'\0\x03\0'+(d/cover).read_bytes())
  n=len(tags);syn=bytes([(n>>j)&127 for j in (21,14,7,0)])
  p=d/f'{title}.mp3';p.write_bytes(b'ID3\x03\0\0'+syn+tags+sound)
  manifest.append({'file':p.name,'title':title,'album':album,'cover':cover if kind=='Art' else None,'audio_sha256':hashlib.sha256(sound).hexdigest(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(d/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('48 paired MP3; same audio SHA',hashlib.sha256(sound).hexdigest())
