import sys
sys.path.insert(0,'work/cover-safety-v11');import qa
qa.guard();qa.sh('am','force-stop',qa.PKG)
path=(qa.E/'provider-19-raw-proof.txt').read_text().splitlines()[1]
qa.adb('push',qa.R/'provider-19-original.jpg',path)
qa.reset_disk()
qa.exercise('v9-clean-pairs',32,2)
