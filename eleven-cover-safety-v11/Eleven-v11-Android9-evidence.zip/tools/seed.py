from pathlib import Path
import os,subprocess,json,time
R=Path('work/cover-safety-v11').resolve();A=Path(os.environ['TEMP'])/'eleven-api30-v5-gpd/sdk/platform-tools/adb.exe'
def adb(*args):
 q=subprocess.run([str(A),'-P','5056','-s','emulator-5600',*map(str,args)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120);assert q.returncode==0,(args,q.stdout,q.stderr);return q.stdout.strip()
assert adb('emu','avd','name').splitlines()[0]=='Eleven_CoverSafety11_28'
assert adb('shell','getprop','ro.kernel.qemu')=='1'
print(adb('push',R/'fixtures','/sdcard/Music/ElevenCoverQA'))
print(adb('shell','sh','-c',"'for f in /sdcard/Music/ElevenCoverQA/*.mp3; do am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$f >/dev/null; done'"))
print(adb('shell','am','start','-n','com.cyanogenmod.eleven.standalone/com.cyanogenmod.eleven.ui.activities.HomeActivity'))
time.sleep(2)
print(adb('shell','content','query','--uri','content://media/external/audio/media','--projection','_id:title:is_music:album_id'))
