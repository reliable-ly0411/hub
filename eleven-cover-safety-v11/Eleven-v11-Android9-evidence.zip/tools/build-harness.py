from pathlib import Path
import zipfile,sys
from build import *
H=R/'harness';H.mkdir(exist_ok=True)
(H/'classes').mkdir(exist_ok=True);(H/'dex').mkdir(exist_ok=True)
(H/'AndroidManifest.xml').write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="qa.eleven.cover"><uses-sdk android:minSdkVersion="21" android:targetSdkVersion="28"/><application android:label="Eleven isolated cover QA"/><instrumentation android:name="qa.CoverInstrumentation" android:targetPackage="com.cyanogenmod.eleven.standalone"/></manifest>''')
run([BT/'aapt.exe','package','-f','-M',H/'AndroidManifest.xml','-I',ANDROID,'-F',H/'resources.apk'])
run([JAVA,'-jar',D/'ecj-3.38.0.jar','-nowarn','-source','8','-target','8','-bootclasspath',str(ANDROID)+';'+str(BT/'core-lambda-stubs.jar'),'-classpath',B/'classes','-d',H/'classes',R/'CoverInstrumentation.java'])
with zipfile.ZipFile(H/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
 for p in (H/'classes').rglob('*.class'):z.write(p,p.relative_to(H/'classes').as_posix())
run([JAVA,'-cp',BT/'lib/d8.jar','com.android.tools.r8.D8','--min-api','21','--lib',ANDROID,'--classpath',B/'classes.jar','--output',H/'dex',H/'classes.jar'])
import shutil
shutil.copyfile(H/'resources.apk',H/'unaligned.apk')
with zipfile.ZipFile(H/'unaligned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write(H/'dex/classes.dex','classes.dex')
run([BT/'zipalign.exe','-f','4',H/'unaligned.apk',H/'aligned.apk']);sign(H/'aligned.apk',H/'Cover-QA.apk')
