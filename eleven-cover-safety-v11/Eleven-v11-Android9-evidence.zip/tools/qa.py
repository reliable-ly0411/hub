from pathlib import Path
import os,subprocess,time,json,re,hashlib,sys
R=Path(__file__).resolve().parent
A=Path(os.environ.get('ELEVEN_QA_ADB',Path(os.environ['TEMP'])/'eleven-api30-v5-gpd/sdk/platform-tools/adb.exe'))
PORT=os.environ.get('ELEVEN_QA_PORT','5056');SERIAL=os.environ.get('ELEVEN_QA_SERIAL','emulator-5600')
PKG='com.cyanogenmod.eleven.standalone';E=R/'evidence';E.mkdir(exist_ok=True)
def adb(*args,check=True,timeout=120):
 q=subprocess.run([str(A),'-P',PORT,'-s',SERIAL,*map(str,args)],capture_output=True,timeout=timeout)
 out=q.stdout.decode('utf-8',errors='replace').strip();err=q.stderr.decode('utf-8',errors='replace').strip()
 if check and q.returncode:raise RuntimeError((args,q.returncode,out,err))
 return out
def sh(*args,**kw):return adb('shell',*args,**kw)
def guard():
 name=adb('emu','avd','name').splitlines()[0]
 assert name in ('Eleven_CoverSafety11_28','Eleven_CoverSafety11_30'),name
 assert sh('getprop','ro.kernel.qemu')=='1'
 assert sh('getprop','ro.build.version.sdk') in ('28','30')
def pid():return sh('pidof',PKG,check=False)
def save(name,s): (E/name).write_text(s,encoding='utf-8')
def shot(name):
 sh('screencap','-p','/data/local/tmp/cover-qa.png');adb('pull','/data/local/tmp/cover-qa.png',E/(name+'.png'))
def sample(label):
 p=pid();mem=sh('dumpsys','meminfo','-d',PKG);save(label+'-meminfo.txt',mem)
 fds=sh('sh','-c',f"'if test -d /proc/{p}/fd; then ls /proc/{p}/fd | wc -l; fi'",check=False) if p else ''
 status=sh('cat',f'/proc/{p}/status',check=False) if p else ''
 save(label+'-proc.txt',status+'\nfd_count='+fds)
 pss=re.search(r'TOTAL\s+(\d+)\s+',mem)
 heaps={}
 for kind in ('Native','Dalvik'):
  m=re.search(rf'{kind} Heap\s+((?:\d+\s+)+)',mem)
  if m and len(m[1].split())>=7:heaps[kind.lower()+'_heap_alloc_kb']=int(m[1].split()[5])
 result={'label':label,'pid':p,'fd_count':int(fds) if fds.isdigit() else None,'pss_kb':int(pss[1]) if pss else None,**heaps,'time':time.time()}
 with (E/'samples.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(result)+'\n')
 print(result,flush=True);return result
def start():return sh('am','start','-n',PKG+'/com.cyanogenmod.eleven.ui.activities.HomeActivity')
def cache_path():return '/sdcard/Android/data/'+PKG+'/cache/ImageCache'
def apksha():
 p=sh('pm','path',PKG).splitlines()[0].removeprefix('package:');return sh('sha256sum',p).split()[0]
def disk_inject(variant=False,index=1):
 guard();sh('am','force-stop',PKG)
 base=f'Cover Art Album {index:02d}_Cover QA_album'
 keys=[base] if not variant else [base+'_safeart_'+str(n) for n in (128,256,512,1024)]
 d=R/('injected-v11' if variant else 'injected-v9');d.mkdir(exist_ok=True)
 journal='libcore.io.DiskLruCache\n1\n1\n1\n\n'
 for k in keys:
  key=hashlib.md5(k.encode()).hexdigest();data=(R/'fixtures/large.jpg').read_bytes()
  (d/(key+'.0')).write_bytes(data);journal+=f'CLEAN {key} {len(data)}\n'
 (d/'journal').write_text(journal,encoding='ascii')
 # Exclusive directory belongs to this newly created emulator, never a handset.
 sh('mkdir','-p',cache_path());adb('push',str(d)+'/.' ,cache_path())
 save(('variant-' if variant else '')+f'{index}-disk-injection.json',json.dumps({'keys':keys,'input':'large.jpg','size':[10000,10000],'jpeg_sha256':hashlib.sha256(data).hexdigest(),'apk_sha256':apksha()},indent=2))

def reset_disk():
 sh('am','force-stop',PKG)
 d=R/'empty-qa-journal';d.write_bytes(b'libcore.io.DiskLruCache\n1\n1\n1\n\n')
 sh('mkdir','-p',cache_path());adb('push',d,cache_path()+'/journal')

def targeted(label,provider=False):
 guard()
 if provider:reset_disk()
 else:disk_inject(index=19)
 sh('logcat','-c');start();time.sleep(1.5)
 sh('input','tap','285','130');time.sleep(.5)
 p=pid();assert p
 # Capture VmRSS and descriptor count in the same guest loop through the crash.
 import concurrent.futures
 command=f"'for i in $(seq 1 100); do test -d /proc/{p}/fd || break; echo $(date +%s.%N) $(ls /proc/{p}/fd | wc -l) $(grep VmRSS /proc/{p}/status) $(grep ^Pss: /proc/{p}/smaps_rollup 2>/dev/null); sleep 0.05; done'"
 before=sample(label+'-before');assert before['pss_kb'] and before['fd_count']
 with concurrent.futures.ThreadPoolExecutor() as pool:
  monitor=pool.submit(sh,'sh','-c',command)
  sh('input','tap','400','64');time.sleep(.5)
  save(label+'-focus.txt',sh('dumpsys','window','windows'))
  sh('input','text','CoverArt19');time.sleep(2)
  after=sample(label+'-after')
  save(label+'-rapid-proc.txt',monitor.result())
 save(label+'-crash.txt',sh('logcat','-b','crash','-d','-v','threadtime'))
 save(label+'-logcat.txt',sh('logcat','-d','-v','threadtime'))
 save(label+'-journal.txt',sh('cat',cache_path()+'/journal',check=False));shot(label+'-after')
 save(label+'-summary.json',json.dumps({'apk_sha256':apksha(),'initial_pid':p,'final_pid':after['pid'],'query':'CoverArt19'},indent=2))
def exercise(label,swipes=64,rounds=5):
 guard();sh('am','force-stop',PKG);sh('logcat','-c');start();time.sleep(1)
 sh('input','tap','285','130');time.sleep(.5)
 initial=pid();assert initial
 result={'label':label,'apk_sha256':apksha(),'initial_pid':initial,'swipes':0,'inserted_chars':0,'queries':[]}
 try:
  sample(label+'-start');shot(label+'-start')
  for i in range(swipes):
   y1,y2=(665,250) if i%16<8 else (250,665)
   sh('input','swipe','260',str(y1),'260',str(y2),'120');result['swipes']+=1
   if i%8==7:sample(label+f'-scroll-{i+1}')
   assert pid()==initial,'PID changed during list scrolling'
  sh('input','tap','400','64');time.sleep(.6)
  for cycle in range(rounds):
   for query in ('CoverPlain','CoverArt'):
    for i,c in enumerate(query):
     sh('input','text',c);result['inserted_chars']+=1
     if cycle==0 and i in (1,2):time.sleep(.35);shot(label+f'-{query}-prefix-{i+1}')
     assert pid()==initial,'PID changed while entering search'
    time.sleep(.3);result['queries'].append(query)
    for j in range(4):sh('input','swipe','260','650','260','300','120')
    if cycle in (0,rounds-1):shot(label+f'-{query}-{cycle}')
    sh('input','keyevent',*(['67']*len(query)))
   sample(label+f'-search-{cycle+1}')
 except Exception as failure:result['error']=str(failure)
 result['final_pid']=pid();save(label+'-crash.txt',sh('logcat','-b','crash','-d','-v','threadtime'))
 save(label+'-logcat.txt',sh('logcat','-d','-v','threadtime'))
 sample(label+'-end');shot(label+'-end');save(label+'-summary.json',json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 return result
if __name__=='__main__':
 guard()
 if sys.argv[1]=='inject':disk_inject('--variant' in sys.argv)
 elif sys.argv[1]=='exercise':exercise(sys.argv[2],int(sys.argv[3]) if len(sys.argv)>3 else 64,int(sys.argv[4]) if len(sys.argv)>4 else 5)
 elif sys.argv[1]=='snapshot':sample(sys.argv[2]);shot(sys.argv[2])
 elif sys.argv[1]=='targeted':targeted(sys.argv[2],'--provider' in sys.argv)
