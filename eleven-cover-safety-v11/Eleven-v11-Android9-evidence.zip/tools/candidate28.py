import qa,hashlib,time,json
qa.guard();assert qa.sh('getprop','ro.build.version.sdk')=='28'
R=qa.R; apk=R/'build/Eleven-v11-cover-safety-candidate.apk'
print(qa.adb('uninstall',qa.PKG),flush=True)
print(qa.adb('install',apk),flush=True)
assert qa.apksha()==hashlib.sha256(apk.read_bytes()).hexdigest()
qa.sh('pm','grant',qa.PKG,'android.permission.READ_EXTERNAL_STORAGE')
qa.targeted('v11-raw-disk-search')
result=json.loads((qa.E/'v11-raw-disk-search-summary.json').read_text());assert result['initial_pid']==result['final_pid']
assert qa.PKG not in (qa.E/'v11-raw-disk-search-crash.txt').read_text()
path=(qa.E/'provider-19-raw-proof.txt').read_text().splitlines()[1]
qa.adb('push',R/'fixtures/large.jpg',path)
proof=qa.sh('sh','-c',"'content read --uri content://media/external/audio/albumart/19 | sha256sum'")
assert proof.split()[0]==hashlib.sha256((R/'fixtures/large.jpg').read_bytes()).hexdigest()
qa.save('v11-provider-19-raw-proof.txt',proof)
qa.targeted('v11-raw-provider-search',True)
result=json.loads((qa.E/'v11-raw-provider-search-summary.json').read_text());assert result['initial_pid']==result['final_pid']
assert qa.PKG not in (qa.E/'v11-raw-provider-search-crash.txt').read_text()
print('Both UI paths alive',flush=True)
