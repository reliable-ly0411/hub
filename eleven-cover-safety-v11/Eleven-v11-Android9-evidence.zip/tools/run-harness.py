import qa, concurrent.futures as cf,time,json,pathlib,hashlib
qa.guard();r=qa.R
print(qa.adb('install',r/'harness/Cover-QA.apk'),flush=True)
qa.sh('am','force-stop',qa.PKG);qa.sh('logcat','-c')
with cf.ThreadPoolExecutor() as e:
 run=e.submit(qa.sh,'am','instrument','-w','-r','qa.eleven.cover/qa.CoverInstrumentation',timeout=240)
 for i in range(50):
  if run.done():break
  if qa.pid():qa.sample(f'v11-direct-harness-{i}')
  time.sleep(2)
 result=run.result()
qa.save('v11-direct-harness-instrument.txt',result)
qa.save('v11-direct-harness-detail.txt',qa.sh('logcat','-d','-s','CoverQA:I','ElevenArtwork:W'))
qa.save('v11-direct-harness-crash.txt',qa.sh('logcat','-b','crash','-d','-v','threadtime'))
print(result,flush=True);assert 'result=PASS' in result,result
