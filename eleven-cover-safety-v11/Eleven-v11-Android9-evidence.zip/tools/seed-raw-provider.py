import sys,re,hashlib
sys.path.insert(0,'work/cover-safety-v11');import qa
qa.guard();qa.sh('am','force-stop',qa.PKG)
albums=qa.sh('content','query','--uri','content://media/external/audio/albums','--projection','_id:album:album_art')
m=re.search(r'_id=19, album=Cover Art Album 19, album_art=(/storage/emulated/0/Android/data/com.android.providers.media/albumthumbs/\d+)',albums);assert m
qa.sh('mkdir','-p','/sdcard/Download/ElevenRawCoverQA')
for p in (qa.R/'fixtures').iterdir():
 if p.suffix in ('.png','.jpg'):
  qa.sh('mv','/sdcard/Music/ElevenCoverQA/'+p.name,'/sdcard/Download/ElevenRawCoverQA/'+p.name)
for idx in range(25,49):qa.sh('content','delete','--uri',f'content://media/external/audio/albumart/{idx}',check=False)
qa.save('provider-pairs-cleaned-albums.txt',qa.sh('content','query','--uri','content://media/external/audio/albums','--projection','_id:album:album_art'))
qa.adb('pull',m[1],qa.R/'provider-19-original.jpg')
qa.adb('push',qa.R/'fixtures/large.jpg',m[1]);raw=hashlib.sha256((qa.R/'fixtures/large.jpg').read_bytes()).hexdigest()
provider=qa.sh('sh','-c',"'content read --uri content://media/external/audio/albumart/19 | sha256sum'");assert provider.split()[0]==raw,provider
qa.save('provider-19-raw-proof.txt',provider+'\n'+m[1])
qa.targeted('v9-raw-provider-search',True)
