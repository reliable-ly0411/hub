from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'
STAGE=sys.argv[1]
VERSIONS=('v9','v13') if STAGE=='comparison' else (('v9',) if STAGE=='v9-initial' else (STAGE,))

def read(api,version):
    return json.loads((ROOT/'evidence'/f'api{api}'/version/'summary.json').read_text(encoding='utf-8'))

def describe(row):
    if 'error' in row:return '场景证据不足 · '+row['error']
    same='PID 一致' if row['pid_before']==row['pid_after_return'] else '切回 PID 已变化'
    extra=' · '+{'recents':'从最近任务切回','launcher':'从应用图标入口切回'}[row['return_route']]
    if 'elapsed_s' in row:
        on_return='切回时在播' if row['playing_on_return'] else '切回时暂停，点一次播放后进度推进'
        if not row['playing_on_return'] and row['advanced_ms']<=300:
            on_return='切回时暂停，点一次播放后的进度推进未证实'
        return (f"关屏后台 {row['elapsed_s']:.1f} 秒 · {same}{extra} · {on_return} · "
                f"进度 {row['start_position_ms']}→{row['end_position_ms']} ms，推进 {row['advanced_ms']} ms · "
                f"后台有 {row['screen_off_samples']} 次关屏采样，PID {'一致' if row['background_pid_stable'] else '变化'}。")
    method={'activity_manager_am_kill':'Android ActivityManager am kill 结束进程',
            'sigkill_simulation_after_am_kill_kept_process':'am kill 保留进程，随后以 SIGKILL 模拟进程死亡'}[row['death_method']]
    auto='自动续播' if row['automatic_continuation'] else '未自动续播'
    if row['single_play_tap_sufficed']:resume='点一次播放即续上'
    elif row['automatic_continuation']:resume='无需点击'
    else:resume='单击播放未证实继续'
    background=f"切回前新 PID {row['pid_after_death_in_background']} 已存在" if row['pid_after_death_in_background'] else '切回前未见新 PID'
    return (f"{method} · 旧 PID {row['pid_before']} 已确认消失，{background}，切回 PID {row['pid_after_return']}{extra} · "
            f"{auto}，{resume} · 回来是否有原曲媒体会话 {'有' if row['same_track_visible_at_return'] else '未见'} · "
            f"上次实测的播放位置 {row['before_bookmark_ms']} ms，回来 {row['position_on_return_ms']} ms，"
            f"续播起点 {row['resumed_from_position_ms']} ms、验证终点 {row['end_position_ms']} ms。")

def recovery_description(row):
    if 'error' in row:
        return '场景证据不足 · '+row['error']
    bookmark=row['bookmark_ms']
    before=row['before']['pid']
    after=row['returned']['pid']
    saved=row['returned']['saved_seekpos_ms']
    session=row['returned']['session']
    route={'recents':'最近任务','launcher':'应用图标入口'}[row['route']]
    visible=f"媒体会话见原曲，进度 {session['position_ms']} ms" if session else '媒体会话未见原曲'
    if 'method' in row:
        method={'activity-manager-am-kill':'ActivityManager am kill',
                'sigkill-after-am-kill-kept-process':'am kill 保留进程后，以 SIGKILL 模拟死亡'}[row['method']]
        background=row['background_before_return']['pid'] or '无'
        setup=f'{method} · 核实旧 PID {before} 消失 · 回来前 PID {background}，回来时 PID {after}'
    else:
        setup=f"关屏 {row['screen_off_seconds']:.1f} 秒 · 原 PID {before}，切回 PID {after}"
    if row['automatic']:
        action=f"自动续播，实测推进 {row['resumed_ms']}→{row['finished_ms']} ms"
    elif row['single_tap_advanced']:
        action=f"没有自动续播，点一次播放后进度 {row['resumed_ms']}→{row['finished_ms']} ms"
    elif row['reselected_track'] and row['reselected_track']['end_ms']-row['reselected_track']['start_ms']>300:
        action=f"点一次播放未续上，在列表重新点原曲后进度 {row['reselected_track']['start_ms']}→{row['reselected_track']['end_ms']} ms"
    else:
        action='点一次播放未证实续上，重新点曲也未证实推进'
    return f'{setup} · 从{route}切回 · {visible} · 死亡或关屏前实测进度 {bookmark} ms，回来时磁盘书签 {saved} ms · {action}。'

def report():
    text=['Eleven 长时间后台与进程恢复复测 · GPD · 2026-11-27','',
          '离线 Android 9 与 Android 11 独立模拟器。v9 和 v13 使用同一首约 7 分半的合成 MP3。每组在播放中按 Home 并关屏 300 秒，回去后用媒体会话暂停时的实际播放进度确认推进；再关屏暂停 60 秒，测回前台后是否能续播。',
          '验证后台进程死亡时先执行 Android ActivityManager 的 am kill。这是受控触发，和设备自然低内存回收不同。若命令保留进程，只在验证过的独立模拟器内使用 SIGKILL 模拟死亡。每次验证原进程消失，并记录切回是否自动播放、是否还能用一次播放键续上。杀进程前的位置列是最近一次实测或保存的点，播放中死亡时可能比死亡瞬间早。','']
    if STAGE=='v9-initial':
        text.append('这是 v9 阶段记录。5 分钟播放场景有完整证据。随后暂停 1 分钟关屏，在两台模拟器上均保留旧 PID，但切回时原曲的媒体会话已清空，且初次点击迷你播放器没有恢复。回收场景没有满足开始条件，下一阶段将独立设起点再测。')
        text.append('')
    for version in VERSIONS:
        for api in (28,30):
            data=read(api,version)
            directory=ROOT/'evidence'/f'api{api}'/version
            text.append(f"{version} / Android {9 if api==28 else 11} · APK {data['apk_sha256']}")
            text.append('播放中关屏 | '+describe(data['cases']['long_playing']))
            first_paused=data['cases']['long_paused']
            if 'error' not in first_paused:
                text.append('5 分钟播放后暂停再关屏 | '+describe(first_paused))
            else:
                raw=(directory/'long-paused-return-session.txt').read_text(encoding='utf-8')
                failed=(directory/'long-paused-tap-after-return-session.txt').read_text(encoding='utf-8')
                assert 'description=Eleven Teal Sample 03' not in raw and 'description=Eleven Teal Sample 03' not in failed
                text.append(f"5 分钟播放后暂停再关屏 | 60 秒后 PID {first_paused['pid']} 仍在，切回与点一次播放后均未见原曲媒体会话。")
            if STAGE!='v9-initial':
                recovery=json.loads((directory/'recovery-probe-result.json').read_text(encoding='utf-8'))
                for key,name in [('pause_60s','重新开始播放后单独测暂停关屏'),('kill_paused','暂停后进程死亡'),('kill_active','播放中进程死亡')]:
                    text.append(name+' | '+recovery_description(recovery[key]))
            rate_file=directory/'rate-probe.json'
            if rate_file.exists() and STAGE!='v9-initial':
                rates=json.loads(rate_file.read_text(encoding='utf-8'))
                for rate in rates:
                    mode='前台' if rate['mode']=='foreground' else '关屏后台'
                    text.append(f"进度对照 | {mode}，持有 {rate['hold_seconds']:.1f} 秒，实际推进 {rate['advanced_ms']/1000:.1f} 秒。")
            more_logs='\n'.join(p.read_text(encoding='utf-8') for p in directory.glob('recovery-probe-*txt') if p.name in ('recovery-probe-crash.txt','recovery-probe-event.txt'))
            more_crashes=any('com.cyanogenmod.eleven.standalone' in line and ('am_crash' in line or 'am_anr' in line or 'Process:' in line) for line in more_logs.splitlines())
            text.append('Eleven 新崩溃或 ANR '+('有' if data['eleven_crash_or_anr'] or more_crashes else '无')+'。')
            text.append('')
    text.extend(['本轮以模拟器媒体会话和实际播放进度为准。用户手机、厂商省电策略、自然发生的低内存回收、超过一分钟的暂停关屏、扬声器实听均未覆盖。'])
    return '\n'.join(text)+'\n'

name='Eleven-background-'+STAGE
target=OUT if STAGE=='comparison' else ROOT
target.mkdir(exist_ok=True)
result=target/(name+'.txt');result.write_text(report(),encoding='utf-8')
zpath=target/(name+'-evidence.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(result,'report.txt')
    for version in VERSIONS:
        for api in (28,30):
            p=ROOT/'evidence'/f'api{api}'/version
            for f in sorted(p.iterdir()):
                if f.is_file():z.write(f,f'evidence/api{api}/{version}/{f.name}')
    for f in ('background_matrix.py','resume_helper.py','package_background.py','playback_recovery_probe.py','playback_rate_probe.py','finish-matrix.ps1'):
        z.write(ROOT/f,'tools/'+f)
    for api in (28,30):z.write(ROOT/f'api{api}/boot.ps1',f'tools/boot-api{api}.ps1')
    z.write(ROOT/'background-fixture.mp3','fixture/background-fixture.mp3')
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
for p in (result,zpath):print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
