import time

import background_matrix as matrix
import resume_helper as test


def probe(mode):
    tag = f'rate-probe-{mode}'
    test.sh('am', 'force-stop', test.PKG)
    test.start_track()
    time.sleep(0.6)
    before = test.pause_progress(tag + '-before')
    matrix.check_play(tag + '-play')
    pid = test.pid()
    if mode == 'screen-off':
        test.leave('launcher', tag)
        matrix.sleep_display(tag)
    started = time.monotonic()
    elapsed, snapshots = matrix.hold(tag, 25)
    route = matrix.restore_from_recents(tag) if mode == 'screen-off' else 'already-foreground'
    after = test.pause_progress(tag + '-after')
    return {
        'mode': mode,
        'hold_seconds': elapsed,
        'until_pause_seconds': round(time.monotonic() - started, 2),
        'screens': [entry['screen'] for entry in snapshots],
        'pid_stable': all(entry['pid'] == pid for entry in snapshots) and test.pid() == pid,
        'route': route,
        'advanced_ms': after - before,
    }


if __name__ == '__main__':
    test.guard()
    test.prepare()
    test.save('rate-probe.json', [probe('foreground'), probe('screen-off')])
