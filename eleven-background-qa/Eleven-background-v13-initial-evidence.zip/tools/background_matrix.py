import json
import re
import time
import resume_helper as t

ACTIVE_SECONDS = 300
PAUSED_SECONDS = 60

def check_play(tag, action=True):
    if action:t.tap(430,766)
    result=t.wait_for(3,tag,5)
    assert result and result['state']==3,result
    return result

def idle_snapshot():
    power=t.sh('dumpsys','power')
    wake=re.search(r'mWakefulness=(\w+)',power)
    return wake[1] if wake else None

def sleep_display(tag):
    t.key(223)
    end=time.monotonic()+3
    while time.monotonic()<end:
        current=idle_snapshot()
        if current in ('Asleep','Dozing'):
            t.save(tag+'-screen-off.txt',current)
            return current
        time.sleep(.25)
    raise AssertionError(f'Display remained {current}')

def restore_from_recents(tag):
    if idle_snapshot() in ('Asleep','Dozing'):
        t.key(224);time.sleep(.4);t.sh('wm','dismiss-keyguard',check=False)
    try:
        t.enter('recents',tag)
        return 'recents'
    except AssertionError as error:
        t.save(tag+'-recents-fallback.txt',str(error))
        t.launcher_entry();t.wait_focus(True)
        return 'launcher'

def hold(tag,seconds):
    started=time.monotonic()
    records=[]
    deadlines=list(range(0,seconds,60))+[seconds]
    for target in deadlines:
        while (remaining:=target-(time.monotonic()-started))>0:
            time.sleep(min(remaining,8))
        snapshot={'elapsed_s':round(time.monotonic()-started,2),'pid':t.pid(),
                  'screen':idle_snapshot(),'session':t.state(f'{tag}-t{target:03d}')}
        records.append(snapshot);t.save(tag+'-hold-progress.json',records)
        print(tag,snapshot,flush=True)
    return round(time.monotonic()-started,2),records

def long_playing():
    name='long-playing'
    t.sh('am','force-stop',t.PKG);t.start_track();time.sleep(.65)
    base=t.pause_progress(name+'-start-position');check_play(name+'-start')
    pid=t.pid();assert pid
    t.leave('launcher',name);sleep_display(name)
    wait,records=hold(name,ACTIVE_SECONDS)
    route=restore_from_recents(name);after_pid=t.pid()
    first=t.state(name+'-return');t.screen(name+'-return')
    automatic=bool(first and first['state']==3)
    if not automatic:check_play(name+'-tap-after-return')
    time.sleep(.75);position=t.pause_progress(name+'-end-position')
    return {'elapsed_s':wait,'pid_before':pid,'pid_after_return':after_pid,'return_route':route,
            'playing_on_return':automatic,'start_position_ms':base,'end_position_ms':position,
            'advanced_ms':position-base,'screen_off_samples':sum(r['screen'] in ('Asleep','Dozing') for r in records),
            'background_pid_stable':all(r['pid']==pid for r in records)}

def long_paused():
    name='long-paused'
    observed=t.state(name+'-before');assert observed and observed['state']==2
    base=observed['position_ms'];pid=t.pid()
    t.leave('launcher',name);sleep_display(name)
    wait,records=hold(name,PAUSED_SECONDS)
    route=restore_from_recents(name);after_pid=t.pid()
    first=t.state(name+'-return');t.screen(name+'-return')
    automatic=bool(first and first['state']==3)
    if not automatic:check_play(name+'-tap-after-return')
    time.sleep(.9);position=t.pause_progress(name+'-end-position')
    return {'elapsed_s':wait,'pid_before':pid,'pid_after_return':after_pid,'return_route':route,
            'playing_on_return':automatic,'position_on_return':first,'start_position_ms':base,
            'end_position_ms':position,'advanced_ms':position-base,
            'screen_off_samples':sum(r['screen'] in ('Asleep','Dozing') for r in records),
            'background_pid_stable':all(r['pid']==pid for r in records)}

def wait_until_gone(target,seconds):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if target not in t.pid().split() and not t.sh(f'test -d /proc/{target} && echo present',check=False):return True
        time.sleep(.30)
    return False

def reclaim(playing):
    name='reclaim-'+('playing' if playing else 'paused')
    t.wait_focus(True)
    current=t.state(name+'-before');assert current,current
    if current['state']==3:
        base=t.pause_progress(name+'-bookmark')
    else:
        assert current['state']==2,current
        base=current['position_ms']
    if playing:check_play(name+'-playing')
    old=t.pid();assert old.isdigit()
    t.leave('launcher',name);time.sleep(3)
    away=t.state(name+'-away');t.save(name+'-processes-before.txt',t.sh('dumpsys','activity','processes'))
    t.save(name+'-am-kill.txt',t.sh('am','kill','--user','0',t.PKG))
    handled=wait_until_gone(old,4)
    if not handled:
        t.guard();assert t.PKG not in t.focus() and t.pid()==old
        command=t.sh('cat',f'/proc/{old}/cmdline').split('\0')[0]
        assert command==t.PKG,(old,command)
        t.sh('kill','-KILL',old)
        assert wait_until_gone(old,5),old
    time.sleep(3)
    background_pid=t.pid();background=t.state(name+'-after-death-before-return')
    method=restore_from_recents(name)
    for i in range(6):
        time.sleep(.48);returned=t.state(name+f'-return-{i+1}')
        if returned and returned['state']==3:break
    new=t.pid();t.screen(name+'-return')
    assert new and old not in new.split(),(old,new)
    automatic=bool(returned and returned['state']==3)
    pos_first=returned['position_ms'] if returned else None
    if not automatic:t.tap(430,766)
    resumed=t.wait_for(3,name+'-active',5)
    success=bool(resumed and resumed['state']==3)
    if success:
        time.sleep(1.0);end=t.pause_progress(name+'-validated-progress')
    else:
        end=None
    start=(resumed or {}).get('position_ms')
    advanced=end-start if end is not None and start is not None else None
    result={'was_playing':playing,'verified_old_process_gone':True,'pid_before':old,
            'pid_after_death_in_background':background_pid,'pid_after_return':new,
            'death_method':'activity_manager_am_kill' if handled else 'sigkill_simulation_after_am_kill_kept_process',
            'return_route':method,'before_bookmark_ms':base,'before_death_session':away,
            'session_before_return':background,'same_track_visible_at_return':returned is not None,
            'position_on_return_ms':pos_first,'automatic_continuation':automatic,
            'single_play_tap_sufficed':bool(not automatic and advanced is not None and advanced>300),
            'resumed_from_position_ms':start,'end_position_ms':end,'advanced_ms':advanced}
    if start is not None:result['bookmark_delta_ms']=start-base
    t.save(name+'-processes-after.txt',t.sh('dumpsys','activity','processes'))
    return result

def main():
    t.guard();t.adb('root');t.adb('wait-for-device');t.guard()
    t.prepare()
    media=(t.E/'media-index.txt').read_text()
    duration=int(re.search(r'title='+t.TITLE+r', duration=(\d+)',media)[1])
    assert duration>(ACTIVE_SECONDS+60)*1000,duration
    for buffer in ('crash','events'):t.sh('logcat','-b',buffer,'-c',check=False)
    result={'api':t.API,'version':t.VERSION,'apk_sha256':t.SHA[t.VERSION], 'fixture_duration_ms':duration,'cases':{}}
    for name,fn in [('long_playing',long_playing),('long_paused',long_paused),
                    ('reclaim_paused',lambda:reclaim(False)),('reclaim_playing',lambda:reclaim(True))]:
        try:
            if name.startswith('reclaim'):
                state,_=t.get_state()
                if not state:
                    t.start_track();time.sleep(2);t.pause_progress(name+'-new-bookmark')
            row=fn()
        except Exception as e:
            row={'error':type(e).__name__+': '+str(e),'pid':t.pid()}
            t.screen(name+'-error')
            t.key(224);t.sh('wm','dismiss-keyguard',check=False);t.launcher_entry()
        result['cases'][name]=row;t.save('partial.json',result)
        print(name,json.dumps(row,ensure_ascii=True),flush=True)
    crash=t.sh('logcat','-b','crash','-d','-v','threadtime',check=False)
    events=t.sh('logcat','-b','events','-d','-s','am_crash:I','am_anr:I','am_kill:I','am_proc_died:I',check=False)
    t.save('crash.txt',crash);t.save('process-events.txt',events)
    result['eleven_crash_or_anr']=t.PKG in crash or any(t.PKG in line and re.search(r'\bam_(crash|anr)',line) for line in events.splitlines())
    t.save('summary.json',result)

if __name__=='__main__':main()
