param([ValidateSet(28,30)][int]$Api)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$initial = "evidence/api$Api/v13/summary.json"
$deadline = (Get-Date).AddMinutes(10)
while (-not (Test-Path -LiteralPath $initial -PathType Leaf)) {
    if ((Get-Date) -gt $deadline) { throw "Timed out waiting for $initial" }
    Start-Sleep -Seconds 2
}

foreach ($version in 'v13','v9') {
    python playback_recovery_probe.py $Api $version
    if ($LASTEXITCODE -ne 0) { throw "Recovery probe failed on API $Api $version" }
    if ($Api -eq 30) {
        python playback_rate_probe.py $Api $version
        if ($LASTEXITCODE -ne 0) { throw "Playback timing probe failed on API $Api $version" }
    }
}
Set-Content -LiteralPath "evidence/api$Api/supplement-done.txt" -Value (Get-Date -Format o)
