import json
import re
import time

import background_matrix as matrix
import resume_helper as test


def service_snapshot(tag):
    services = test.sh('dumpsys', 'activity', 'services', test.PKG)
    test.save(tag + '-services.txt', services)
    prefs = test.sh('cat', f'/data/data/{test.PKG}/shared_prefs/Service.xml', check=False)
    test.save(tag + '-saved-service.xml', prefs)
    match = re.search(r'name="seekpos" value="(\d+)"', prefs)
    return {
        'pid': test.pid(),
        'session': test.state(tag),
        'saved_seekpos_ms': int(match[1]) if match else None,
        'playback_service_present': 'MusicPlaybackService' in services,
    }


def setup_case(tag):
    test.sh('am', 'force-stop', test.PKG)
    test.start_track()
    time.sleep(5)
    position = test.pause_progress(tag + '-initial-paused')
    assert position > 1000, position
    return position


def attempt_return(tag, before_position):
    route = matrix.restore_from_recents(tag)
    time.sleep(1.25)
    returned = service_snapshot(tag + '-returned')
    test.screen(tag + '-returned')
    already_playing = bool(returned['session'] and returned['session']['state'] == 3)
    if not already_playing:
        test.tap(430, 766)
    replayed = test.wait_for(3, tag + '-first-play-button', 5)
    result = {'route': route, 'returned': returned, 'automatic': already_playing,
              'single_tap_advanced': False, 'reselected_track': None}
    if replayed and replayed['state'] == 3:
        time.sleep(1.6)
        finished = test.pause_progress(tag + '-verified-position')
        result.update({'resumed_ms': replayed['position_ms'], 'finished_ms': finished,
                       'automatic': already_playing and finished - replayed['position_ms'] > 300,
                       'single_tap_advanced': not already_playing and finished - replayed['position_ms'] > 300,
                       'offset_from_bookmark_ms': replayed['position_ms'] - before_position})
    else:
        result['after_failed_play_button'] = service_snapshot(tag + '-play-button-failed')
        test.screen(tag + '-play-button-failed')
        test.tap(165, 236)
        fallback = test.wait_for(3, tag + '-reselected-track', 5)
        if fallback and fallback['state'] == 3:
            time.sleep(1.6)
            finished = test.pause_progress(tag + '-reselected-verified-position')
            result['reselected_track'] = {'start_ms': fallback['position_ms'], 'end_ms': finished}
    return result


def paused_without_kill(tag='recovery-probe-paused-60s'):
    before_position = setup_case(tag)
    before = service_snapshot(tag + '-before')
    test.leave('launcher', tag)
    matrix.sleep_display(tag)
    elapsed, samples = matrix.hold(tag, 60)
    away = service_snapshot(tag + '-before-wake')
    return {'bookmark_ms': before_position, 'before': before,
            'screen_off_seconds': elapsed, 'samples': samples, 'away': away,
            **attempt_return(tag, before_position)}


def controlled_death(playing):
    tag = 'recovery-probe-kill-' + ('active' if playing else 'paused')
    before_position = setup_case(tag)
    if playing:
        matrix.check_play(tag + '-playing')
    before = service_snapshot(tag + '-before')
    pid = before['pid']
    assert pid.isdigit(), pid
    test.leave('launcher', tag)
    time.sleep(3)
    away = service_snapshot(tag + '-prekill')
    test.save(tag + '-processes-prekill.txt', test.sh('dumpsys', 'activity', 'processes'))
    assert away['pid'] == pid, away
    if playing:
        assert away['session'] and away['session']['state'] == 3, away
    elif away['session']:
        assert away['session']['state'] == 2, away
    test.save(tag + '-am-kill.txt', test.sh('am', 'kill', '--user', '0', test.PKG))
    method = 'activity-manager-am-kill'
    if not matrix.wait_until_gone(pid, 5):
        test.guard()
        assert test.PKG not in test.focus() and test.pid() == pid
        assert test.sh('cat', f'/proc/{pid}/cmdline').split('\0')[0] == test.PKG
        test.sh('kill', '-KILL', pid)
        assert matrix.wait_until_gone(pid, 5), pid
        method = 'sigkill-after-am-kill-kept-process'
    time.sleep(3)
    background = service_snapshot(tag + '-postkill')
    result = attempt_return(tag, before_position)
    new_pid = result['returned']['pid']
    assert new_pid.isdigit() and new_pid != pid, (pid, new_pid)
    return {'bookmark_ms': before_position, 'before': before, 'away': away,
            'old_pid_verified_gone': True, 'method': method, 'background_before_return': background, **result}


if __name__ == '__main__':
    test.guard()
    test.prepare()
    for buffer in ('crash', 'events'):
        test.sh('logcat', '-b', buffer, '-c', check=False)
    rows = {}
    for name, task in [('kill_paused', lambda: controlled_death(False)),
                       ('kill_active', lambda: controlled_death(True)),
                       ('pause_60s', paused_without_kill)]:
        try:
            rows[name] = task()
        except Exception as error:
            rows[name] = {'error': repr(error)}
            test.screen('recovery-probe-' + name + '-error')
        print(name, json.dumps(rows[name]), flush=True)
        test.save('recovery-probe-result.json', rows)
    test.save('recovery-probe-crash.txt', test.sh('logcat', '-b', 'crash', '-d', '-v', 'threadtime', check=False))
    test.save('recovery-probe-event.txt', test.sh('logcat', '-b', 'events', '-d', '-s',
              'am_crash:I', 'am_anr:I', 'am_kill:I', 'am_proc_died:I', 'am_create_service:I',
              'am_destroy_service:I', 'am_uid_idle:I', 'am_stop_idle_service:I', check=False))
    system_activity = test.sh('logcat', '-b', 'system', '-d', '-v', 'threadtime', '-s', 'ActivityManager', check=False)
    test.save('recovery-probe-system-activity.txt', '\n'.join(line for line in system_activity.splitlines() if test.PKG in line))
