import json
import sys
import time

import playback_recovery_probe as recovery
import resume_helper as test


def relaunch_after_failed_return(case):
    tag = 'relaunch-probe'
    assert not case['automatic'] and not case['single_tap_advanced'] and not case['reselected_track'], case
    before = recovery.service_snapshot(tag + '-before')
    assert before['session'] is None, before
    test.sh('am', 'force-stop', test.PKG)
    assert not test.pid()
    test.launcher_entry()
    test.wait_focus(True)
    time.sleep(1.2)
    returned = recovery.service_snapshot(tag + '-opened')
    test.screen(tag + '-opened')
    assert before['pid'] != returned['pid'] and returned['pid'], returned
    test.tap(430, 766)
    active = test.wait_for(3, tag + '-play', 5)
    finished = None
    if active and active['state'] == 3:
        time.sleep(1.6)
        finished = test.pause_progress(tag + '-verified-position')
    return {
        'pid_before': before['pid'],
        'pid_opened': returned['pid'],
        'bookmark_ms': case['bookmark_ms'],
        'opened_session': returned['session'],
        'resumed_ms': active['position_ms'] if finished is not None else None,
        'finished_ms': finished,
        'relaunch_then_one_tap_advanced': finished is not None and finished - active['position_ms'] > 300,
    }


if __name__ == '__main__':
    test.guard()
    mode = sys.argv[3]
    if mode == 'reproduce':
        test.prepare()
        case = recovery.paused_without_kill('relaunch-probe-reproduced-pause')
        test.save('relaunch-probe-reproduced-pause.json', case)
    else:
        original = json.loads((test.E / 'recovery-probe-result.json').read_text(encoding='utf-8'))
        case = original['pause_60s']
    result = relaunch_after_failed_return(case)
    test.save('relaunch-probe-result.json', result)
    print(json.dumps(result), flush=True)
